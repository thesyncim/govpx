from pathlib import Path
import subprocess,tarfile,io,re
snapshot=subprocess.check_output(['git','archive','42bac3ce697f71ae783a13b9c9a4fb540c29e581'])
for variant in ['bits','fold']:
 root=Path('/private/tmp/govpx-next-filter-check-'+variant);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:t.extractall(root)
 f=root/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=f.read_text()
 if variant=='bits':
  def repl(m):
   k=int(m.group(1))-1
   return 'nonzero := f.Add(archsimd.BroadcastInt8x16('+str(k)+')).ToBits().Greater(archsimd.BroadcastUint8x16('+str(2*k)+')).ToInt8x16().ToBits().ReshapeToUint64s()\n if nonzero.GetElem(0)|nonzero.GetElem(1) != 0 {'
  s,n=re.subn(r'if f.Abs\(\).ToBits\(\).ReduceMax\(\) >= ([34]) \{',repl,s);assert n==4
 else:
  needle='bits := need.ToInt8x16().ToBits().ReshapeToUint64s()\n\t\tif bits.GetElem(0)|bits.GetElem(1) != 0 {'
  assert s.count(needle)==4
  # Remove the earlier mask branch and keep the single exact correction check.
  # The intervening HEV/f work now also runs for completely masked-off edges.
  start=0;edits=[]
  while True:
   a=s.find(needle,start)
   if a<0:break
   b=a+len(needle);depth=1;i=b
   while depth:
    if s[i]=='{':depth+=1
    elif s[i]=='}':depth-=1
    i+=1
   edits.append((a,b,i-1));start=i
  for a,b,end in reversed(edits):s=s[:end]+s[end+1:];s=s[:a]+s[b:]
 f.write_text(s);print(root)
