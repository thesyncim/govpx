from pathlib import Path
import subprocess,tarfile,io
root=Path('/private/tmp/govpx-next-luma-fullmask');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','42bac3ce697f71ae783a13b9c9a4fb540c29e581']))) as t:t.extractall(root)
f=root/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=f.read_text();needle='if f.Abs().ToBits().ReduceMax() >= ';assert s.count(needle)==4
s=s.replace(needle,'if bits.GetElem(0)&bits.GetElem(1) != ^uint64(0) || f.Abs().ToBits().ReduceMax() >= ');f.write_text(s)
p=root/'internal/vp8/decoder/picker_filter_native_bench_test.go';p.write_bytes(Path('/private/tmp/govpx-next-filter-small/internal/vp8/decoder/picker_filter_native_bench_test.go').read_bytes())
print(root)
