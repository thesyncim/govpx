from pathlib import Path
import subprocess,tarfile,io
root=Path('/private/tmp/govpx-next-quant-pair-component');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','a39defa388e7b93a84f42ab00887c0febc84bb8b']))) as t:t.extractall(root)
patch=Path('benchmarks/baselines/go127-simd-arm64/2026-10-17-rejected-quant-pair/quant-pair.patch').read_text()
added='\n'.join(line[1:] for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++'))
added=added.replace('i0.Masked(t0.NotEqual(z))','i0.AndNot(t0.Equal(z).ToInt16x8())').replace('i1.Masked(t1.NotEqual(z))','i1.AndNot(t1.Equal(z).ToInt16x8())').replace('i0.Masked(t2.NotEqual(z))','i0.AndNot(t2.Equal(z).ToInt16x8())').replace('i1.Masked(t3.NotEqual(z))','i1.AndNot(t3.Equal(z).ToInt16x8())')
f=root/'internal/pixel/quantize_vp8_batch_arm64.go';s=f.read_text();assert s.count('\tfor i := range count {')==1
f.write_text(s.replace('\tfor i := range count {',added))
print(root)
