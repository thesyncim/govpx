import os,subprocess,pathlib,json,re,statistics
out=pathlib.Path('/private/tmp/govpx-next-sad-reduction-measure');out.mkdir(exist_ok=True)
bins={'parent':'/private/tmp/govpx-next-sad-x4-fused.test','candidate':'/private/tmp/govpx-next-sad-reduction.test','assembly':'/private/tmp/govpx-next-sad-x4-assembly.test'}
env=dict(os.environ,GOMAXPROCS='1');rows={v:{} for v in bins}
orders=[['parent','candidate','assembly'],['assembly','candidate','parent']]
for r,order in enumerate(orders,1):
 for v in order:
  pattern='^BenchmarkSADLimit(Native|X4Native)$/pitch(32|1312)/extreme(false|true)/(bound|wide)$'
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench='+pattern,'-test.benchtime=200ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  matches=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(matches)==16,len(matches)
  for name,ns,b,a in matches:
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns))
 print('round',r,'done',flush=True)
summary={k:{'samples':{v:rows[v][k] for v in bins},'speedup':statistics.median(rows['parent'][k])/statistics.median(rows['candidate'][k]),'speedup_assembly':statistics.median(rows['assembly'][k])/statistics.median(rows['candidate'][k]),'faster_pairs':sum(a>b for a,b in zip(rows['parent'][k],rows['candidate'][k]))} for k in rows['parent']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
