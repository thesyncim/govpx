from pathlib import Path
import subprocess,tarfile,io
root=Path('/private/tmp/govpx-next-sad-reduction');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','a39defa388e7b93a84f42ab00887c0febc84bb8b']))) as t:t.extractall(root)
f=root/'internal/pixel/goav1_sad_arm64.go';s=f.read_text()
a='\treturn sumU16(even) + sumU16(odd)'
b='\tif h <= 16 { return int(even.Add(odd).ReduceSum()) }\n'+a
assert s.count(a)==1;s=s.replace(a,b)
a='\treturn sumU16(a0), sumU16(a1), sumU16(a2), sumU16(a3)'
b='\tif h <= 16 { return int(a0.ReduceSum()), int(a1.ReduceSum()), int(a2.ReduceSum()), int(a3.ReduceSum()) }\n'+a
assert s.count(a)==1;s=s.replace(a,b);f.write_text(s)
print(root)
