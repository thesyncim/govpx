from pathlib import Path
import subprocess,tarfile,io
root=Path('/private/tmp/govpx-next-sad-x4-prefix');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','a39defa388e7b93a84f42ab00887c0febc84bb8b']))) as t:t.extractall(root)
f=root/'internal/vp8/dsp/sad_dispatch_other.go';s=f.read_text()
old='\tout[0] = uint32(SAD16x16LimitPtrFast(src, srcStride, ref0, refStride, int(limits[0])))'
new=''' if pixel.Enabled && sadX4FullDisjoint(src, srcStride, ref0, ref1, ref2, ref3, refStride, limits, out) {
  *out = pixel.SAD16x4PrefixPtr(src,srcStride,ref0,ref1,ref2,ref3,refStride,*limits)
  return
 }
'''+old
assert s.count(old)==1;f.write_text(s.replace(old,new))
body='''//go:build goexperiment.simd && arm64 && !purego

package pixel
import ("simd/archsimd";"unsafe")

// SAD16x4PrefixPtr requires readable 16x16 windows and snapshots the limits.
// All outputs are the exact first row prefix strictly greater than their limit,
// or the full sum. The DSP caller proves output cannot change any input.
func SAD16x4PrefixPtr(src *byte,ss int,r0,r1,r2,r3 *byte,rs int,limits [4]int32) (out [4]uint32) {
 sp:=unsafe.Pointer(src)
 p0,p1,p2,p3:=unsafe.Pointer(r0),unsafe.Pointer(r1),unsafe.Pointer(r2),unsafe.Pointer(r3)
 s:=load16(sp)
 a0:=absPairs(s,load16(p0));a1:=absPairs(s,load16(p1));a2:=absPairs(s,load16(p2));a3:=absPairs(s,load16(p3))
 out[0]=uint32(a0.ReduceSum());out[1]=uint32(a1.ReduceSum());out[2]=uint32(a2.ReduceSum());out[3]=uint32(a3.ReduceSum())
 active:=0
 if int(out[0])<=int(limits[0]) {active|=1};if int(out[1])<=int(limits[1]) {active|=2};if int(out[2])<=int(limits[2]) {active|=4};if int(out[3])<=int(limits[3]) {active|=8}
 for y:=1;y<16 && active!=0;y++ {
  s=load16(unsafe.Add(sp,y*ss));off:=y*rs
  if active&1!=0 {a0=a0.Add(absPairs(s,load16(unsafe.Add(p0,off))));out[0]=uint32(a0.ReduceSum());if int(out[0])>int(limits[0]) {active &^=1}}
  if active&2!=0 {a1=a1.Add(absPairs(s,load16(unsafe.Add(p1,off))));out[1]=uint32(a1.ReduceSum());if int(out[1])>int(limits[1]) {active &^=2}}
  if active&4!=0 {a2=a2.Add(absPairs(s,load16(unsafe.Add(p2,off))));out[2]=uint32(a2.ReduceSum());if int(out[2])>int(limits[2]) {active &^=4}}
  if active&8!=0 {a3=a3.Add(absPairs(s,load16(unsafe.Add(p3,off))));out[3]=uint32(a3.ReduceSum());if int(out[3])>int(limits[3]) {active &^=8}}
 }
 return
}
'''
# The explicitly typed accumulator declarations establish four SIMD lanes;
# drop the unused import after replacing inferred first-row declarations.
body=body.replace('a0:=absPairs','var a0,a1,a2,a3 archsimd.Uint16x8\n a0=absPairs').replace(';a1:=absPairs',';a1=absPairs').replace(';a2:=absPairs',';a2=absPairs').replace(';a3:=absPairs',';a3=absPairs')
(root/'internal/pixel/sad_x4_prefix_arm64.go').write_text(body)
print(root)
