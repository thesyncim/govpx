//go:build goexperiment.simd && arm64 && !purego

package pixel
import ("simd/archsimd";"unsafe")

// SAD16x4PrefixPtr requires readable 16x16 windows and snapshots the limits.
// All outputs are the exact first row prefix strictly greater than their limit,
// or the full sum. The DSP caller proves output cannot change any input.
func SAD16x4PrefixPtr(src *byte,ss int,r0,r1,r2,r3 *byte,rs int,limits [4]int32) (out [4]uint32) {
 sp:=unsafe.Pointer(src)
 p0,p1,p2,p3:=unsafe.Pointer(r0),unsafe.Pointer(r1),unsafe.Pointer(r2),unsafe.Pointer(r3)
 s:=load16(sp)
 var a0,a1,a2,a3 archsimd.Uint16x8
 a0=absPairs(s,load16(p0));a1=absPairs(s,load16(p1));a2=absPairs(s,load16(p2));a3=absPairs(s,load16(p3))
 out[0]=uint32(a0.ReduceSum());out[1]=uint32(a1.ReduceSum());out[2]=uint32(a2.ReduceSum());out[3]=uint32(a3.ReduceSum())
 active:=0
 if int(out[0])<=int(limits[0]) {active|=1};if int(out[1])<=int(limits[1]) {active|=2};if int(out[2])<=int(limits[2]) {active|=4};if int(out[3])<=int(limits[3]) {active|=8}
 for y:=1;y<16 && active!=0;y++ {
  s=load16(unsafe.Add(sp,y*ss));off:=y*rs
  if active&1!=0 {a0=a0.Add(absPairs(s,load16(unsafe.Add(p0,off))));out[0]=uint32(a0.ReduceSum());if int(out[0])>int(limits[0]) {active &^=1}}
  if active&2!=0 {a1=a1.Add(absPairs(s,load16(unsafe.Add(p1,off))));out[1]=uint32(a1.ReduceSum());if int(out[1])>int(limits[1]) {active &^=2}}
  if active&4!=0 {a2=a2.Add(absPairs(s,load16(unsafe.Add(p2,off))));out[2]=uint32(a2.ReduceSum());if int(out[2])>int(limits[2]) {active &^=4}}
  if active&8!=0 {a3=a3.Add(absPairs(s,load16(unsafe.Add(p3,off))));out[3]=uint32(a3.ReduceSum());if int(out[3])>int(limits[3]) {active &^=8}}
 }
 return
}
