from pathlib import Path
import subprocess, tarfile, io, re
snapshot=subprocess.check_output(['git','archive','a39defa388e7b93a84f42ab00887c0febc84bb8b'])
root=Path('/private/tmp/govpx-next-filter-lanes');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:t.extractall(root)
f=root/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=f.read_text()
pattern=r'archsimd.BroadcastUint64x2\(uint64\(\*\(\*uint32\)\(unsafe.Add\(ptr, (\d)\*outer\)\)\)\|uint64\(\*\(\*uint32\)\(unsafe.Add\(ptr, (\d)\*outer\)\)\)<<32\).SetElem\(1, uint64\(\*\(\*uint32\)\(unsafe.Add\(ptr, (\d+)\*outer\)\)\)\|uint64\(\*\(\*uint32\)\(unsafe.Add\(ptr, (\d+)\*outer\)\)\)<<32\).ReshapeToUint16s\(\)'
def replacement(m):
 rows=m.groups()
 return 'archsimd.BroadcastUint32x4(*(*uint32)(unsafe.Add(ptr, '+rows[0]+'*outer)))'+''.join('.SetElem('+str(i)+', *(*uint32)(unsafe.Add(ptr, '+rows[i]+'*outer)))' for i in range(1,4))+'.ReshapeToUint16s()'
s,n=re.subn(pattern,replacement,s);assert n==8,n
f.write_text(s)
print(root,n)
