import subprocess, os, json, time
from pathlib import Path
bins={'parent':'/private/tmp/govpx-next-filter-parent.test','lanes':'/private/tmp/govpx-next-filter-lanes.test'}
rows=[]
env=dict(os.environ,GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1')
for i,order in enumerate([['parent','lanes'],['lanes','parent']]*3):
 for variant in order:
  p=subprocess.run([bins[variant],'-test.run=^$','-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=250ms','-test.count=1'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert p.returncode==0,p.stdout
  rows.append({'round':i+1,'variant':variant,'output':p.stdout})
 Path('/private/tmp/govpx-next-filter-lanes-measure.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('round',i+1,'done',flush=True)
