from pathlib import Path
import json, hashlib, tarfile, io
base = Path('/private/tmp'); out = base / 'govpx-gather-unrolled-ready'; out.mkdir(exist_ok=True)
payload = {}
for p in base.glob('govpx-next-gather-unrolled*'):
    if p.is_file() and p.suffix in ['.py', '.txt', '.json', '.log']:
        payload[p.name] = p.read_bytes()
    if p.is_dir() and (p / 'summary.json').exists():
        for q in p.iterdir():
            if q.is_file() and q.suffix in ['.txt', '.json']: payload[p.name + '/' + q.name] = q.read_bytes()
for name in ['govpx-gather-pointer-full-native-test.go', 'govpx-archive-gather-unrolled.py', 'govpx-summarize-public.py']:
    payload[name] = (base / name).read_bytes()
names = ['internal/pixel/gather_pointer_simd.go', 'internal/pixel/gather_pointer_generic.go', 'internal/pixel/gather_pointer_test.go', 'internal/pixel/gather_pointer_disabled_amd64_test.go', 'internal/vp8/dsp/gather_pointer_native_test.go', 'internal/vp8/dsp/gather_pointer_rows_test.go', 'internal/vp8/dsp/residual_gather_other.go', 'cmd/govpx-bench/benchcmd/search_routing_fixed_digest_test.go']
for variant, directory in {'candidate': 'govpx-next-gather-unrolled', 'loop': 'govpx-next-gather-pointer', 'parent': 'govpx-next-uv-fusion-parent', 'assembly': 'govpx-next-uv-zero-assembly'}.items():
    for name in names:
        p = base / directory / name
        if p.exists(): payload['sources/' + variant + '/' + name] = p.read_bytes()
for name in names:
    p = Path(name)
    if p.exists(): payload['final-production/' + name] = p.read_bytes()
with tarfile.open(out / 'raw-and-sources.tar.gz', 'w:gz') as t:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name); info.size, info.mtime = len(data), 0; t.addfile(info, io.BytesIO(data))
(out / 'raw-sha256.json').write_text(json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(payload.items())}, indent=2) + '\n')
component = json.loads((base / 'govpx-next-gather-unrolled-confirm/summary.json').read_text())
public = json.loads((base / 'govpx-next-gather-unrolled-public-summary.json').read_text())
assert len(component) == 18 and all(x['minimum_paired_speedup'] >= 1.5 and x['faster_assembly_pairs'] == 6 for x in component.values())
(out / 'component-summary.json').write_text(json.dumps(component, indent=2) + '\n')
(out / 'public-summary.json').write_text(json.dumps(public, indent=2) + '\n')
bins = ['govpx-next-gather-unrolled.test', 'govpx-next-gather-unrolled-root-bench', 'govpx-next-gather-pointer-parent-packed-confirm.test', 'govpx-next-gather-pointer-assembly-packed-confirm.test', 'govpx-next-gather-pointer-candidate-packed-confirm.test', 'govpx-next-uv-zero-candidate-bench', 'govpx-asm-bench']
env = {'cpu': 'Apple M4 Max', 'compiler': 'Go1.27.2 darwin/arm64 GOEXPERIMENT=simd', 'pgo': 'off', 'goprocs': 1, 'threads': 1, 'parent_tested': '03afac7c47a7ce3e7f52d0925308f95932b2a9df', 'parent_merged': '9f333e012876038ad46800217ff64e186c7b8796 (identical tested tree)', 'assembly': '691cd0512c4829d9ee40d483205dd223f9eb028d', 'binary_sha256': {n: hashlib.sha256((base / n).read_bytes()).hexdigest() for n in bins}, 'final_source_sha256': {n: hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names if Path(n).exists()}, 'raw_members': len(payload)}
(out / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
report = '''# Fixed-row pointer SIMD residual gather

Native Apple M4 Max,Go1.27.2 archsimd,PGOoff,GOMAXPROCS1. Parent03afac7c
merged as9f333e01 with identical tree; pinned assembly691cd051. The looped
pointer predecessor already gave1.5x representative gains and remains fully
preserved in the separate looped-gather archive. Fixed row groups remove its
loop address setup while retaining exact paired-row arithmetic/store order.
Guards, input/output bounds and aliases keep the same proven pointer contract.

Fresh six balanced main/ASM/current permutations, with the looped predecessor
as an additional first/last alternating control. All four binaries use exactly
the same18 public-operation fixtures: original two, eight unaligned/minimal
row windows with unequal padded strides, and eight tightly packed predictors;
random and extreme values. New fixtures check all coefficients with independent
scalar equations, full input immutability and output canaries after B.Loop.
150ms per fixture, zero bytes and allocations in every sample.

'''
for width in [8, 16]:
    cases = [x for n, x in component.items() if f'/w{width}/' in n or n.endswith(f'/{width}x{width}')]
    report += f"{width}x{width}: {min(x['speedup'] for x in cases):.4f}–{max(x['speedup'] for x in cases):.4f}x main; {min(x['speedup_assembly'] for x in cases):.4f}–{max(x['speedup_assembly'] for x in cases):.4f}x assembly; {min(x['speedup_loop'] for x in cases):.4f}–{max(x['speedup_loop'] for x in cases):.4f}x the looped pointer version.\n\n"
report += f"All108 paired samples beat main by at least {int(min(x['minimum_paired_speedup'] for x in component.values())*1000)/1000:.3f}x and beat assembly. Keep these verified component wins independently of overall codec results under AGENTS.md. Every raw sample/outlier and the earlier diagnostic remain archived.\n\n"
report += 'Whole synthetic720p VP8,realtimeCPU8,2500kbps,one thread,six fresh balanced three-way permutations using the final root binary:\n'
for frames in ['300', '60']:
    x = public[frames]
    report += f"\n* {frames}frames: {x['vs_parent_percent']:+.3f}% encode time versus main ({x['faster_parent_pairs']}/6 faster), {x['vs_assembly_percent']:+.3f}% versus assembly ({x['faster_assembly_pairs']}/6 faster).\n"
report += '''
All23 non-timing result fields match and allocations stay zero. Whole and
component results remain separate; the overall ARM assembly gap is still open.

Validation: full native ./...,336 public repeated/overlapping-row, alignment
and extreme cases plus existing randomized/minimal-window oracles; explicit
successful helper assertions with mutually aliased read-only inputs; nil,
stride1<<48/negative and disabled declines; race/checkptr2; six fixed-speed
packet bytes/drop-position digests exactly matching parent; refreshed PGO and
fingerprint/noasm/build-selection/precommit. The first fixed-packet command
matched no tests (plural typo); its log is retained and the corrected singular
run executes all six cases. No empty-run claim is used.

Final ARM hot instruction words exactly match the timed prototype:108 lines
for8x8 and282 for16x16. Only leading addresses and in-function absolute branch
renderings are normalized; raw instruction words also compare exactly.
Both ARM functions are leaf code without bounds-panic calls. AMD cross-codegen
uses146/399 instruction lines, no bounds-panic or arithmetic calls;16x16 has a
cold stack-growth call and stack scratch for row addresses. These counts are
diagnostics, not acceptance criteria or native x64 performance claims.
AMD selected/actualAVX-off arithmetic and all18 fixture checks pass under
Rosetta for correctness only. Native x64 CI measures the final production
candidate before merge. No README or dependency changes.
'''
(out / 'REPORT.md').write_text(report)
print(out, len(payload))
