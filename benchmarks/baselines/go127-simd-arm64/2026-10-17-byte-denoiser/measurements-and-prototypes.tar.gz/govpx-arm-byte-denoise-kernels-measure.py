import os,subprocess
from pathlib import Path
w='/Users/thesyncim/.codex/bin/project-env'
env=dict(os.environ,GOMAXPROCS='1',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='root-arm-denoise-kernels')
variants=['parent','safe','pointer'];orders=[[0,1,2],[1,2,0],[2,0,1],[0,2,1],[2,1,0],[1,0,2]]
for r,order in enumerate(orders):
 for i in order:
  name=variants[i]
  out=subprocess.check_output([w,'/private/tmp/govpx-arm-denoise-'+name+'-encoder.test','-test.run=^$','-test.bench=^BenchmarkDenoiserFilterYNative$','-test.benchtime=200ms','-test.count=1','-test.cpu=1','-test.benchmem'],env=env,text=True)
  Path('/private/tmp/govpx-arm-denoise-'+name+'-kernels-round'+str(r+1)+'.txt').write_text(out)
 print('ARM denoiser public kernel round',r+1,'done',flush=True)
