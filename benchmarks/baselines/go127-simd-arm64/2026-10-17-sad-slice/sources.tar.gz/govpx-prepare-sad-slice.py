from pathlib import Path
import subprocess,tarfile,io
root=Path('/Users/thesyncim/GolandProjects/govpx')
for name in ['parent','candidate']:
 dst=Path('/private/tmp/govpx-next-sad-slice-'+name);dst.mkdir(exist_ok=True)
 data=subprocess.check_output(['git','archive','b05fb1f7'],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(dst)
 old=(root/'internal/vp8/dsp/sad_limit_native_test.go').read_text()
 bench=old[old.index('func BenchmarkSADLimitNative'):].replace('BenchmarkSADLimitNative','BenchmarkSADLimitSliceNative').replace('SAD16x16LimitPtrFast(&a[0], ss, &ref[0], rs, tc.limit)','SAD16x16Limit(a, ss, ref, rs, tc.limit)')
 (dst/'internal/vp8/dsp/sad_limit_slice_native_test.go').write_text('package dsp\nimport("fmt";"testing")\n'+bench)
 if name=='candidate':
  p=dst/'internal/vp8/dsp/sad_dispatch_other.go';s=p.read_text();needle='func sadBlock16x16Limit(src []byte, srcStride int, ref []byte, refStride int, limit int) int {\n';assert s.count(needle)==1
  s=s.replace(needle,needle+'\tif pixel.Enabled {\n\t\treturn SAD16x16LimitPtrFast(unsafe.SliceData(src), srcStride, unsafe.SliceData(ref), refStride, limit)\n\t}\n');p.write_text(s)
