import os,subprocess,pathlib,json,re,statistics
out=pathlib.Path('/private/tmp/govpx-next-sad-x4-diagnostic');out.mkdir(exist_ok=True)
bins={'parent':'/private/tmp/govpx-next-sad-x4-parent.test','candidate':'/private/tmp/govpx-next-sad-x4-candidate.test'}
env=os.environ.copy();env['GOMAXPROCS']='1';rows={v:{} for v in bins}
for r,order in enumerate([['parent','candidate'],['candidate','parent']]*3,1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkSADLimitX4Native$/pitch(32|1312)/extremefalse/(bound|early|middle)$','-test.benchtime=250ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout)
  if p.returncode: raise SystemExit(p.stdout)
  found=0
  for name,ns,b,a in re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M):
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns));found+=1
  assert found==6,(v,p.stdout)
summary={k:{'samples':{v:rows[v][k] for v in bins},'speedup':statistics.median(rows['parent'][k])/statistics.median(rows['candidate'][k]),'faster_pairs':sum(a>b for a,b in zip(rows['parent'][k],rows['candidate'][k]))} for k in rows['parent']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
