from pathlib import Path
import struct,hashlib,json
out={}
for v in ['parent','fused']:
 p=Path('/private/tmp/govpx-next-sad-x4-'+v+'-bench');d=p.read_bytes();h=struct.unpack_from('<IiiIIIII',d);assert h[0]==0xfeedfacf
 pos=32;sections={}
 for _ in range(h[4]):
  cmd,size=struct.unpack_from('<II',d,pos)
  if cmd==0x19:
   n=struct.unpack_from('<I',d,pos+64)[0]
   for k in range(n):
    a=pos+72+k*80;name=d[a:a+16].split(b'\0')[0].decode();seg=d[a+16:a+32].split(b'\0')[0].decode();length=struct.unpack_from('<Q',d,a+40)[0];offset=struct.unpack_from('<I',d,a+48)[0]
    if name=='__text':sections[seg+','+name]={'length':length,'offset':offset,'sha256':hashlib.sha256(d[offset:offset+length]).hexdigest()}
  pos+=size
 out[v]={'binary_sha256':hashlib.sha256(d).hexdigest(),'sections':sections}
a,b=out['parent']['sections']['__TEXT,__text'],out['fused']['sections']['__TEXT,__text'];out['instruction_text_identical']=(a['length'],a['sha256'])==(b['length'],b['sha256']);out['scope']='Native ARM PGO-off CLI builds. Source search finds the x4 limited entry point only at its definition in production. Machine-text identity is code-generation evidence, not an end-to-end timing measurement. Debug/build metadata can differ.'
normal=[]
for v in ['parent','fused']:
 section=out[v]['sections']['__TEXT,__text']
 d=bytearray(Path('/private/tmp/govpx-next-sad-x4-'+v+'-bench').read_bytes()[section['offset']:section['offset']+section['length']])
 prefix=b'\xff Go build ID: "';assert d.startswith(prefix)
 end=d.index(b'"\n \xff',len(prefix));assert all(32<=c<127 for c in d[len(prefix):end])
 out[v]['go_build_id_payload_bytes']=[len(prefix),end]
 d[len(prefix):end]=bytes(end-len(prefix))
 out[v]['text_with_only_build_id_payload_zeroed_sha256']=hashlib.sha256(d).hexdigest();normal.append(d)
out['instruction_text_identical_after_build_id_payload_normalization']=normal[0]==normal[1]
assert normal[0]==normal[1]
out['unused_x4_entry_and_guard_symbols_absent']=not Path('/private/tmp/govpx-next-sad-x4-cli-unused-symbols.txt').read_text().strip()
out['scope']+=' Raw text differs only in the validated Go build-ID string payload. Zero only that non-instruction payload; every remaining text byte matches. X4 limited entry and guard symbols are absent from the selected CLI. No whole-codec speedup is measured or claimed.'
Path('/private/tmp/govpx-next-sad-x4-cli-proof.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
