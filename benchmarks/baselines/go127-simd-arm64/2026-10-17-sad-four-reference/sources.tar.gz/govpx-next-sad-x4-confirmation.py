import os,subprocess,pathlib,json,re,statistics
out=pathlib.Path('/private/tmp/govpx-next-sad-x4-confirmation');out.mkdir(exist_ok=True)
bins={v:'/private/tmp/govpx-next-sad-x4-'+v+'.test' for v in ['parent','assembly','candidate']}
env=os.environ.copy();env['GOMAXPROCS']='1';rows={v:{} for v in bins}
orders=[['parent','assembly','candidate'],['assembly','candidate','parent'],['candidate','parent','assembly'],['parent','candidate','assembly'],['candidate','assembly','parent'],['assembly','parent','candidate']]
for r,order in enumerate(orders,1):
 for v in order:
  groups=[('all','^BenchmarkSADLimitX4Native$',20)]
  if v=='assembly':groups=[('patterned-compatible','^BenchmarkSADLimitX4Native$/pitch(32|1312)/extremefalse/(bound|wide|near|early)$',8),('extreme','^BenchmarkSADLimitX4Native$/pitch(32|1312)/extremetrue/',10)]
  for label,pattern,count in groups:
   p=subprocess.run([bins[v],'-test.run=^$','-test.bench='+pattern,'-test.benchtime=200ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   (out/f'{r}-{v}-{label}.txt').write_text(p.stdout)
   if p.returncode:raise SystemExit(p.stdout)
   found=0
   for name,ns,b,a in re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M):
    assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns));found+=1
   assert found==count,(v,label,p.stdout)
summary={}
for k in rows['parent']:
 samples={v:rows[v][k] for v in bins if k in rows[v]}
 summary[k]={'samples':samples,'speedup_vs_parent':statistics.median(samples['parent'])/statistics.median(samples['candidate']),'min_paired_speedup_vs_parent':min(a/b for a,b in zip(samples['parent'],samples['candidate'])),'faster_parent_pairs':sum(a>b for a,b in zip(samples['parent'],samples['candidate'])),'speedup_vs_assembly':statistics.median(samples['assembly'])/statistics.median(samples['candidate']) if 'assembly' in samples else None,'assembly_scope':'Pinned NEON x4 has incompatible row-prefix results for patterned middle cases; initial failed exact-oracle log retained. Those two cases have no assembly timing.' if 'assembly' not in samples else 'Exact fixture oracle passes.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
