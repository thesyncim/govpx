from pathlib import Path
import subprocess,tarfile,io
root=Path.cwd()
for name in ['parent','candidate']:
 p=Path('/private/tmp/govpx-next-sad-x4-'+name);p.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD']))) as t:t.extractall(p)
 if name=='candidate':
  f=p/'internal/vp8/dsp/sad_dispatch_other.go';s=f.read_text()
  for i in range(4):
   old=f'sadBlockLimitScalarPtr(src, srcStride, ref{i}, refStride, 16, 16, int(limits[{i}]))'
   new=f'SAD16x16LimitPtrFast(src, srcStride, ref{i}, refStride, int(limits[{i}]))'
   assert s.count(old)==1;s=s.replace(old,new)
  f.write_text(s)
