//go:build goexperiment.simd && amd64 && !purego
package pixel
func pixelStatsRows16Arch(src []byte, ss int, ref []byte, rs, w, h int)(uint32,int32){return pixelStatsRows16Generic(src,ss,ref,rs,w,h)}
