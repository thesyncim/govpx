// SPDX-License-Identifier: BSD-2-Clause
// Copied from goav1 0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a; exact-span fallback added.
// See third_party/goav1/LICENSE.
//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// pixelStatsRows16Arch is pixelStatsRows16 with NEON's widening multiply: the
// int16 differences square straight into int32 lanes (SMULL on the low and
// high halves) instead of being sign-extended first, and the signed sum
// accumulates in int16 lanes (at most 510 per 16-sample step, flushed to
// int32 every 32 steps).
func pixelStatsRows16Arch(src []byte, srcStride int, ref []byte, refStride int, w, h int) (uint32, int32) {
	if h <= 0 {
		return 0, 0
	}
	// Check lengths before subtracting or dividing. For each accepted window,
	// (h-1)*stride+w <= len, proving every exact16B row load without overflow.
	if w < 16 || w > 64 || w&15 != 0 || srcStride < 0 || refStride < 0 || w > len(src) || w > len(ref) ||
		(h > 1 && (srcStride > (len(src)-w)/(h-1) || refStride > (len(ref)-w)/(h-1))) {
		return pixelStatsRows16Generic(src, srcStride, ref, refStride, w, h)
	}
	sp := unsafe.Pointer(&src[0])
	rp := unsafe.Pointer(&ref[0])
	var sse0, sse1, sum32 archsimd.Int32x4
	var sum16 archsimd.Int16x8
	// At width16/32/48/64 each chunk has at most64packets, so
	// |sum16| <=2*255*64=32640. Flush outside the hot packet loop.
	rowsPerChunk := 1024 / w
	for base := 0; base < h; {
		rows := min(rowsPerChunk, h-base)
		for r := base; r < base+rows; r++ {
			s, p := unsafe.Add(sp, r*srcStride), unsafe.Add(rp, r*refStride)
			for c := 0; c < w; c += 16 {
				a, b := load16(unsafe.Add(s, c)), load16(unsafe.Add(p, c))
				dl := a.ExtendLo8ToUint16().BitsToInt16().Sub(b.ExtendLo8ToUint16().BitsToInt16())
				dh := widenHi8(a).BitsToInt16().Sub(widenHi8(b).BitsToInt16())
				sum16 = sum16.Add(dl).Add(dh)
				sse0 = sse0.Add(dl.MulWidenLo(dl)).Add(dh.MulWidenLo(dh))
				dl, dh = dl.HiToLo(), dh.HiToLo()
				sse1 = sse1.Add(dl.MulWidenLo(dl)).Add(dh.MulWidenLo(dh))
			}
		}
		sum32 = sum32.Add(sum16.ExtendLo4ToInt32()).Add(sum16.HiToLo().ExtendLo4ToInt32())
		sum16 = archsimd.Int16x8{}
		base += rows
	}
	total, signed := reducePixelAcc(sse0.Add(sse1), sum32)
	return uint32(total), int32(signed)
}
