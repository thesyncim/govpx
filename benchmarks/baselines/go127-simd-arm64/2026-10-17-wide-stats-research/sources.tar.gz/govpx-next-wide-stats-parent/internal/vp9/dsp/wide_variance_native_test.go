package dsp
import("testing";"fmt")
var wideVarianceNativeSink VarianceStats
func BenchmarkVP9WideVarianceNative(b *testing.B){
 for _,shape:=range [][2]int{{16,16},{32,16},{32,32},{32,64},{64,32},{64,64}}{for _,pitch:=range []int{96,1312}{for mode:=range 2{
 w,h:=shape[0],shape[1];b.Run(fmt.Sprintf("%dx%d/pitch%d/mode%d",w,h,pitch,mode),func(b *testing.B){
 ss,rs:=pitch,pitch+13;a,r:=make([]byte,3+(h-1)*ss+w)[3:],make([]byte,5+(h-1)*rs+w)[5:]
 for i:=range a{if mode==0{a[i]=byte(i*37+11)}else{a[i]=255}};for i:=range r{if mode==0{r[i]=byte(i*19+53)}}
 var sum int64;var sq uint32;for y:=range h{for x:=range w{d:=int64(a[y*ss+x])-int64(r[y*rs+x]);sum+=d;sq+=uint32(d*d)}}
 want:=VarianceStats{Sum:int32(sum),SSE:sq,Variance:sq-uint32(sum*sum/int64(w*h))};var got VarianceStats;ok:=false
 b.ReportAllocs();for b.Loop(){got,ok=VpxVarianceStats(a,0,ss,r,0,rs,w,h)};b.StopTimer();if !ok||got!=want{b.Fatalf("got%+v selected%v want%+v",got,ok,want)};wideVarianceNativeSink=got
 })}}}
}
