import os,subprocess,pathlib,json,re,statistics
out=pathlib.Path('/private/tmp/govpx-next-wide-stats-tiled-diagnostic');out.mkdir(exist_ok=True)
bins={'parent':'/private/tmp/govpx-next-wide-stats-parent.test','tiled':'/private/tmp/govpx-next-wide-stats-tiled.test'}
env=os.environ.copy();env['GOMAXPROCS']='1';rows={v:{} for v in bins}
for r,order in enumerate([['parent','tiled'],['tiled','parent']]*3,1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkVP9WideVarianceNative$/(16x16|32x32|64x64)/pitch(96|1312)/mode0$','-test.benchtime=250ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout)
  if p.returncode: raise SystemExit(p.stdout)
  found=0
  for name,ns,b,a in re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M):
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns));found+=1
  assert found==6,(v,p.stdout)
summary={k:{'samples':{v:rows[v][k] for v in bins},'speedup':statistics.median(rows['parent'][k])/statistics.median(rows['tiled'][k]),'faster_pairs':sum(a>b for a,b in zip(rows['parent'][k],rows['tiled'][k]))} for k in rows['parent']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
