from pathlib import Path
import shutil
src=Path('/private/tmp/govpx-next-wide-stats-tiled'); dst=Path('/private/tmp/govpx-next-wide-stats-unrolled');shutil.copytree(src,dst,dirs_exist_ok=True)
p=dst/'internal/pixel/goav1_pixelstats_rows16_arm64.go'
s=p.read_text();i=s.index('\tsp := unsafe.Pointer'); end=s.index('\n}',i)
body='\tsp, rp := unsafe.Pointer(&src[0]), unsafe.Pointer(&ref[0])\n'
for width in [32,64]:
 n=width//16
 body+=f'\tif w == {width} {{\n'
 body+='\t\tvar '+', '.join(f'e{k}, o{k}' for k in range(n))+', sum32 archsimd.Int32x4\n'
 body+='\t\tfor base := 0; base < h; {\n\t\t\trows := min(64, h-base)\n'
 body+='\t\t\tvar '+', '.join(f't{k}' for k in range(n))+' archsimd.Int16x8\n'
 body+='\t\t\tfor r := base; r < base+rows; r++ {\n\t\t\t\ts, p := unsafe.Add(sp, r*srcStride), unsafe.Add(rp, r*refStride)\n'
 for k in range(n):
  body+='\t\t\t\t{\n'
  body+=f'\t\t\t\t\ta, b := load16(unsafe.Add(s, {16*k})), load16(unsafe.Add(p, {16*k}))\n'
  body+='\t\t\t\t\tdl := a.ExtendLo8ToUint16().BitsToInt16().Sub(b.ExtendLo8ToUint16().BitsToInt16())\n\t\t\t\t\tdh := widenHi8(a).BitsToInt16().Sub(widenHi8(b).BitsToInt16())\n'
  body+=f'\t\t\t\t\tt{k} = t{k}.Add(dl).Add(dh)\n\t\t\t\t\te{k} = e{k}.Add(dl.MulWidenLo(dl)).Add(dh.MulWidenLo(dh))\n\t\t\t\t\tdl, dh = dl.HiToLo(), dh.HiToLo()\n\t\t\t\t\to{k} = o{k}.Add(dl.MulWidenLo(dl)).Add(dh.MulWidenLo(dh))\n\t\t\t\t}}\n'
 body+='\t\t\t}\n'
 for k in range(n): body+=f'\t\t\tsum32 = sum32.Add(t{k}.ExtendLo4ToInt32()).Add(t{k}.HiToLo().ExtendLo4ToInt32())\n'
 body+='\t\t\tbase += rows\n\t\t}\n'
 acc='e0.Add(o0)'+''.join(f'.Add(e{k}).Add(o{k})' for k in range(1,n))
 body+=f'\t\ttotal, signed := reducePixelAcc({acc}, sum32)\n\t\treturn uint32(total), int32(signed)\n\t}}\n'
s=s[:i]+body+s[i:end]+s[end:]
s=s.replace('int32 every 32 steps).','int32 every 64 steps).')
s=s.replace('\tsp := unsafe.Pointer(&src[0])\n\trp := unsafe.Pointer(&ref[0])\n','')
p.write_text(s)
