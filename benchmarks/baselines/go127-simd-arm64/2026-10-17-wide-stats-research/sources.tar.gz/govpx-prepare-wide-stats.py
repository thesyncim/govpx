from pathlib import Path
import subprocess
root=Path('/private/tmp/govpx-next-wide-stats');p=root/'internal/pixel/goav1_pixelstats_simd.go';s=p.read_text();needle='func pixelStatsRows16(src []byte, srcStride int, ref []byte, refStride int, w, h int) (sse uint32, sum int32) {';assert s.count(needle)==1
s=s.replace(needle,'''func pixelStatsRows16(src []byte, srcStride int, ref []byte, refStride int, w, h int) (sse uint32, sum int32) {
 return pixelStatsRows16Arch(src, srcStride, ref, refStride, w, h)
}
func pixelStatsRows16Generic(src []byte, srcStride int, ref []byte, refStride int, w, h int) (sse uint32, sum int32) {''');p.write_text(s)
src=subprocess.check_output(['git','-C','/Users/thesyncim/GolandProjects/goav1','show','0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a:internal/av1/encoder/pixelstats_rows16_arm64.go'],text=True)
src=src.replace('package encoder','package pixel');needle='\t_ = src[(h-1)*srcStride+w-1]\n\t_ = ref[(h-1)*refStride+w-1]\n';assert needle in src
src=src.replace(needle,''' // Check lengths before subtracting or dividing. For each accepted window,
 // (h-1)*stride+w <= len, proving every exact16B row load without overflow.
 if srcStride < 0 || refStride < 0 || w > len(src) || w > len(ref) ||
  (h > 1 && (srcStride > (len(src)-w)/(h-1) || refStride > (len(ref)-w)/(h-1))) {
  return pixelStatsRows16Generic(src, srcStride, ref, refStride, w, h)
 }
''')
src='// SPDX-License-Identifier: BSD-2-Clause\n// Copied from goav1 0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a; exact-span fallback added.\n// See third_party/goav1/LICENSE.\n'+src
(root/'internal/pixel/goav1_pixelstats_rows16_arm64.go').write_text(src)
(root/'internal/pixel/goav1_pixelstats_rows16_amd64.go').write_text('''//go:build goexperiment.simd && amd64 && !purego
package pixel
func pixelStatsRows16Arch(src []byte, ss int, ref []byte, rs, w, h int)(uint32,int32){return pixelStatsRows16Generic(src,ss,ref,rs,w,h)}
''')
bench='''package dsp
import("testing";"fmt")
var wideVarianceNativeSink VarianceStats
func BenchmarkVP9WideVarianceNative(b *testing.B){
 for _,shape:=range [][2]int{{16,16},{32,16},{32,32},{32,64},{64,32},{64,64}}{for _,pitch:=range []int{96,1312}{for mode:=range 2{
 w,h:=shape[0],shape[1];b.Run(fmt.Sprintf("%dx%d/pitch%d/mode%d",w,h,pitch,mode),func(b *testing.B){
 ss,rs:=pitch,pitch+13;a,r:=make([]byte,3+(h-1)*ss+w)[3:],make([]byte,5+(h-1)*rs+w)[5:]
 for i:=range a{if mode==0{a[i]=byte(i*37+11)}else{a[i]=255}};for i:=range r{if mode==0{r[i]=byte(i*19+53)}}
 var sum int64;var sq uint32;for y:=range h{for x:=range w{d:=int64(a[y*ss+x])-int64(r[y*rs+x]);sum+=d;sq+=uint32(d*d)}}
 want:=VarianceStats{Sum:int32(sum),SSE:sq,Variance:sq-uint32(sum*sum/int64(w*h))};var got VarianceStats;ok:=false
 b.ReportAllocs();for b.Loop(){got,ok=VpxVarianceStats(a,0,ss,r,0,rs,w,h)};b.StopTimer();if !ok||got!=want{b.Fatalf("got%+v selected%v want%+v",got,ok,want)};wideVarianceNativeSink=got
 })}}}
}
'''
for d in ['govpx-next-wide-stats','govpx-next-wide-stats-parent','govpx-next-denoise-assembly']:(Path('/private/tmp')/d/'internal/vp9/dsp/wide_variance_native_test.go').write_text(bench)
