from pathlib import Path
import json,hashlib,tarfile,io
base=Path('/private/tmp');out=base/'govpx-subpel-identity-ready';out.mkdir(exist_ok=True);payload={}
for p in base.glob('govpx-next-subpel-identity*'):
 if p.is_file() and p.suffix in ['.py','.log','.txt','.json','.go']:payload[p.name]=p.read_bytes()
 if p.is_dir() and (p/'summary.json').exists():
  for q in p.iterdir():
   if q.is_file() and q.suffix in ['.json','.txt']:payload[p.name+'/'+q.name]=q.read_bytes()
for n in ['govpx-archive-subpel-identity.py','govpx-prepare-subpel-identity.py']:payload[n]=(base/n).read_bytes()
names=['internal/pixel/kernels_simd.go','internal/pixel/subpel_identity_simd_test.go','internal/pixel/goav1_pixelstats_simd.go','internal/pixel/stats16_arm64.go','internal/pixel/stats16_amd64.go','internal/vp9/dsp/subpel_pointer_native_test.go','scripts/benchmark-amd64.sh']
for v in ['parent','candidate']:
 for n in names:
  p=base/('govpx-next-subpel-identity-'+v)/n
  if p.exists():payload['sources/'+v+'/'+n]=p.read_bytes()
for n in names:payload['final-production/'+n]=Path(n).read_bytes()
with tarfile.open(out/'raw-and-sources.tar.gz','w:gz') as t:
 for n,d in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size,info.mtime=len(d),0;t.addfile(info,io.BytesIO(d))
(out/'raw-sha256.json').write_text(json.dumps({n:hashlib.sha256(d).hexdigest() for n,d in sorted(payload.items())},indent=2)+'\n')
x=json.loads((base/'govpx-next-subpel-identity-confirm/summary.json').read_text());ids={n:r for n,r in x.items() if 'phase0-0' in n};controls={n:r for n,r in x.items() if 'phase0-0' not in n}
assert len(x)==40 and len(ids)==8 and all(r['minimum_paired_speedup']>=1.5 and r['faster_parent_pairs']==6 for r in ids.values())
(out/'component-summary.json').write_text(json.dumps(x,indent=2)+'\n')
env={'cpu':'Apple M4 Max','compiler':'Go1.27.2 darwin/arm64 archsimd PGOoff','goprocs':1,'parent':'a54017990dbf927ff67b48681f46c81309614f25','assembly':'691cd0512c4829d9ee40d483205dd223f9eb028d','raw_members':len(payload),'final_source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names},'binaries_sha256':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['govpx-next-subpel-identity-parent.test','govpx-next-subpel-identity-candidate.test','govpx-next-subpel-identity-assembly.test']},'whole_codec':'pending for this shared shortcut; earlier vertical-only results separate','native_x64_speed':'pending CI; no emulated speed claims'}
(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
r='''# Reuse SIMD statistics for identity subpixel phases

Native Apple M4 Max, Go1.27.2 archsimd, PGOoff,GOMAXPROCS1. Parent a5401799
and pinned assembly691cd051. Exact fx=fy={128,0} evaluates each bilinear stage
to the input byte:128*p+64 fits signedint16 (64..32704), shifted7 equals p.
For w,h<=64, reuse the existing SIMD Stats kernel rather than multiply identity
weights and load irrelevant neighbor values. Keep BOTH original bilinear
endpoint checks first, including the otherwise unnecessary row/column. Positive
dimensions/nonnegative strides follow original dispatch; stride<2^30 proves
endpoint arithmetic cannot overflow. Other coefficients/geometry/CPUoff retain
unchanged paths. No input writes or retained pointers; read-only aliases valid.

Fresh six balanced parent/assembly/current permutations,100ms per40 public
fixtures, all zero B/op and allocations. Identical B.Loop sources and scalar
variance/SSE equations, minimum visible spans, unaligned3/5 origins, minimal
and unequal padded strides, full immutable backing-buffer checks and sinks.
All oldASM phase-specific algorithms remain legitimate strong controls.

| Full-pixel public fixture | Parent/current time ratio | Assembly/current time ratio | Minimum paired parent/current |
|---|---:|---:|---:|
'''
for n,a in ids.items():r+=f"| {n.split('Native/')[1]} | {a['speedup']:.4f}x | {a['speedup_assembly']:.4f}x | {a['minimum_paired_speedup']:.4f}x |\n"
r+=f'''
All48 identity pairs exceed {min(a['minimum_paired_speedup'] for a in ids.values()):.4f}x parent.
Keep this correctness-verified >=1.5x component win independently of overall
codec performance under AGENTS.md. Other32 phase controls range
{min(a['speedup'] for a in controls.values()):.4f}–{max(a['speedup'] for a in controls.values()):.4f}x parent; retain every slower control
and all raw samples/outliers. Only16x8 beats assembly here; other measured sizes
still trail assembly. This is not blanket assembly parity or a general2x claim.

Whole-codec effect of this last shared shortcut is pending and is not inferred
from kernel results. Earlier vertical-filter-only whole measurements remain
separately scoped. Native x64 performance waits for the exact-head246-case CI
comparison; Rosetta measurements are never speed evidence.

Independent review passed exact arithmetic, numeric ranges, endpoint/panic
contracts, aliases, fallbacks and existing Stats AVX cleanup. |sum|<=1,044,480
andSSE<=266,342,400; ARM16 narrow paired bound32640 and AMD16 bound16320 fit
int16. Width4/quads,8/paired,24/generic and32/64 row reductions remain exact.
Existing extreme and64-phase oracles pass;72 new identity alias/stride/shape
cases and40 short-window panic cases pass. Native harness requires identity
tests in selected/scalar/race/checkptr coverage; same40 fixture and all206older
controls retained, eight benchmark/production hashes recorded.

Initial two-round40case diagnostic, freshsix confirmation, full source/driver
snapshots and correctness/codegen logs are preserved. No concurrent local
builds/profiles during timing. README files and dependencies remain unchanged.
'''
(out/'REPORT.md').write_text(r);print(out,len(payload))
