import os,subprocess,pathlib,json,re,statistics,hashlib
out=pathlib.Path('/private/tmp/govpx-next-denoise-confirmation');out.mkdir(exist_ok=True)
bins={'parent':'/private/tmp/govpx-next-denoise-parent.test','assembly':'/private/tmp/govpx-next-denoise-assembly.test','pointers':'/private/tmp/govpx-next-denoise-pointers.test'}
env=os.environ.copy();env['GOMAXPROCS']='1'
rows={v:{} for v in bins}
orders=[['parent','assembly','pointers'],['assembly','pointers','parent'],['pointers','parent','assembly'],['parent','pointers','assembly'],['pointers','assembly','parent'],['assembly','parent','pointers']]
for r,order in enumerate(orders,1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkDenoiserFilterYNative$','-test.benchtime=250ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout)
  if p.returncode: raise SystemExit(p.stdout)
  found=0
  for name,ns,b,a in re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M):
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns));found+=1
  assert found==3,(v,p.stdout)
summary={k:{'samples':{v:rows[v][k] for v in bins},'speedup_vs_parent':{v:statistics.median(rows['parent'][k])/statistics.median(rows[v][k]) for v in bins},'faster_pairs':{v:sum(a>b for a,b in zip(rows['parent'][k],rows[v][k])) for v in bins}} for k in rows['parent']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
