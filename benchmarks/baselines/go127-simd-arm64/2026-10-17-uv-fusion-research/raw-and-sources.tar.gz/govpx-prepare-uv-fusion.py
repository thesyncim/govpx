from pathlib import Path
root = Path('/private/tmp/govpx-next-uv-fusion-candidate')
src = (root/'internal/pixel/loopfilter_uv_arith_simd.go').read_text()
load = src[src.index('\tvar p3,'):src.index('\n\td1,')]
calc = src[src.index('\td1,'):src.index('\n\tthree, four :=')]
old = 'if bits.GetElem(0)|bits.GetElem(1) == 0 {\n\t\treturn\n\t}'
assert calc.count(old) == 1
calc = calc.replace(old, 'if bits.GetElem(0)|bits.GetElem(1) != 0 {')
old = 'if uvRoundedZero(f, kind) {\n\t\treturn\n\t}'
assert calc.count(old) == 1
calc = calc.replace(old, 'if !uvRoundedZero(f, kind) {')
begin = src.index('\tthree, four :=')
middle = src.index('\n\tf1, f2 :=')
macro = src[begin:middle].replace('\tz := archsimd.Uint8x16{}\n', '')
assert macro.count('\n\t\treturn\n\t}') == 1
macro = macro.replace('\n\t\treturn\n\t}', '\n\t\tq0,q1,q2=nq0,nq1,nq2\n\t}')
common = src[begin:src.index('\n\tif kind == 6 {', begin)]
internal = common + src[middle:src.rindex('\n}')]
header = src[:src.index('func loopFilterUVBytes')]
header = header.replace('Paired eight-position planes share the canonical byte-filter arithmetic.', 'Macroblock and internal UV edges carry the modified neighboring pixels.')
body = '''func loopFilterMacroInternalUVBytes(planeU, planeV []byte, step, outer, mblimit, blimit, limit, thresh int) {
 off:=4*step
'''+load+'\n{\nconst kind=6\n'+calc.replace('byte(blimit)', 'byte(mblimit)')+'\n'+macro+'\n}}}\n'
body += '''p3,p2,p1,p0=q0,q1,q2,q3
off=8*step
if step==1 {
 a0,a1,a2,a3,_,_,_,_:=loadLFColumnTile[[4]byte](planeU,off,outer)
 b0,b1,b2,b3,_,_,_,_:=loadLFColumnTile[[4]byte](planeV,off,outer)
 q0,q1,q2,q3=joinLFBytes(a0,b0),joinLFBytes(a1,b1),joinLFBytes(a2,b2),joinLFBytes(a3,b3)
} else {
 q0,q1,q2,q3=loadLFUVByte(planeU,planeV,off),loadLFUVByte(planeU,planeV,off+step),loadLFUVByte(planeU,planeV,off+2*step),loadLFUVByte(planeU,planeV,off+3*step)
}
{const kind=4
'''+calc+'\n'+internal+'\n}}}\n}\n'
(root/'internal/pixel/loopfilter_macro_internal_uv_arith_simd.go').write_text(header+body)
wrapper = (root/'internal/pixel/loopfilter_uv_simd.go').read_text()
start = wrapper.index('func LoopFilterUV8')
end = wrapper.index('\nfunc loadLFUVByte',start)
wrapper = wrapper[start:end]
wrapper = wrapper.replace('LoopFilterUV8(u, v []byte, step, outer, blimit, limit, thresh, kind int)', 'LoopFilterMacroInternalUV8(u, v []byte, step, outer, mblimit, blimit, limit, thresh int)')
wrapper = wrapper.replace('(kind != 4 && kind != 6)', '(mblimit < 0 || mblimit >= 255)')
wrapper = wrapper.replace('(step == 1 && outer >= 8)', '(step == 1 && outer >= 12)')
a = wrapper.index('\t// An eight-by-eight')
b = wrapper.index('\tup, vp :=',a)
wrapper = wrapper[:a]+'''// Prove the exact12x8 window before multiplying either stride.
 avail:=min(len(u),len(v))-1
 if avail<0 || step>avail/11 {return false}
 avail-=11*step
 if outer>avail/7 {return false}
'''+wrapper[b:]
wrapper = wrapper.replace('loopFilterUVBytes(u, v, 4*step, step, outer, blimit, limit, thresh, kind)', 'loopFilterMacroInternalUVBytes(u, v, step, outer, mblimit, blimit, limit, thresh)')
(root/'internal/pixel/loopfilter_macro_internal_uv_simd.go').write_text('//go:build goexperiment.simd && (arm64 || amd64) && !purego\n\npackage pixel\nimport "unsafe"\n'+wrapper+'\n')
(root/'internal/pixel/loopfilter_macro_internal_uv_nosimd.go').write_text('//go:build !goexperiment.simd || (!arm64 && !amd64) || purego\n\npackage pixel\nfunc LoopFilterMacroInternalUV8(_, _ []byte, _, _, _, _, _, _ int) bool {return false}\n')
p=root/'internal/vp8/decoder/loopfilter.go';s=(root.parent/'govpx-next-uv-fusion-parent/internal/vp8/decoder/loopfilter.go').read_text();a=s.index('func applyNormalLoopFilterChromaOnlyMB');b=s.index('\nfunc ',a+1);body=s[a:b]
body=body.replace('if col > 0 {', 'fusedV := macroInternalLoopFilter && col>0 && !skipLF && pixel.LoopFilterMacroInternalUV8(img.U[uOff-4:],img.V[vOff-4:],1,img.UStride,int(mblim),int(blim),int(lim),int(hev))\n if col > 0 && !fusedV {',1)
body=body.replace('if !skipLF {','if !skipLF && !fusedV {',1)
body=body.replace('if row > 0 {', 'fusedH := macroInternalLoopFilter && row>0 && !skipLF && pixel.LoopFilterMacroInternalUV8(img.U[uOff-4*img.UStride:],img.V[vOff-4*img.VStride:],img.UStride,1,int(mblim),int(blim),int(lim),int(hev))\n if row > 0 && !fusedH {',1)
where=body.rindex('if !skipLF {');body=body[:where]+body[where:].replace('if !skipLF {','if !skipLF && !fusedH {',1)
p.write_text(s[:a]+body+s[b:])
print(root)
