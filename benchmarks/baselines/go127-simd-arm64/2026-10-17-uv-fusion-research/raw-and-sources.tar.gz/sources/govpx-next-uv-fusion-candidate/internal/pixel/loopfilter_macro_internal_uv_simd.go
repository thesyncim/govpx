//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import "unsafe"

func LoopFilterMacroInternalUV8(u, v []byte, step, outer, mblimit, blimit, limit, thresh int) bool {
	if !Enabled || (mblimit < 0 || mblimit >= 255) || blimit < 0 || blimit >= 255 || limit < 0 || limit > 255 || thresh < 0 || thresh > 255 {
		return false
	}
	if !((outer == 1 && step >= 8) || (step == 1 && outer >= 12)) {
		return false
	}
	// Prove the exact12x8 window before multiplying either stride.
	avail := min(len(u), len(v)) - 1
	if avail < 0 || step > avail/11 {
		return false
	}
	avail -= 11 * step
	if outer > avail/7 {
		return false
	}
	up, vp := uintptr(unsafe.Pointer(unsafe.SliceData(u))), uintptr(unsafe.Pointer(unsafe.SliceData(v)))
	if (up <= vp && vp-up < uintptr(len(u))) || (vp < up && up-vp < uintptr(len(v))) {
		return false
	}
	loopFilterMacroInternalUVBytes(u, v, step, outer, mblimit, blimit, limit, thresh)
	return true
}
