//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import (
	"bytes"
	"testing"
)

func TestUVMacroInternalExact(t *testing.T) {
	if !Enabled {
		t.Skip("SIMD backend unavailable")
	}
	for _, vertical := range []bool{false, true} {
		for _, pitch := range []int{12, 13, 32, 672} {
			for align := range 8 {
				for _, limits := range [][4]int{{0, 0, 0, 0}, {1, 1, 1, 0}, {32, 17, 9, 0}, {64, 33, 32, 8}, {254, 254, 255, 255}} {
					mb, bl, lim, thr := limits[0], limits[1], limits[2], limits[3]
					for pattern := range 10 {
						step, outer := pitch, 1
						if vertical {
							step, outer = 1, pitch
						}
						u, v := bytes.Repeat([]byte{0xa7}, align+11*step+7*outer+1+13), bytes.Repeat([]byte{0xb9}, align+11*step+7*outer+1+13)
						for axis := range 12 {
							for lane := range 8 {
								val := byte([]int{0, 127, 128, 255, 0, 0, 0, 0, 0, 0}[pattern])
								vval := val
								if pattern >= 6 {
									d := axis / 4
									if pattern >= 8 {
										d *= 2
									}
									if pattern%2 != 0 {
										d = -d
									}
									val = byte(128 + d)
									vval = byte(101 + d)
								} else if pattern >= 4 {
									val = byte(32 + lane*3 + axis)
									vval = byte(48 + lane*3 + axis)
									if pattern == 5 && axis == 4 && lane == 7 {
										vval += 6
									}
								}
								u[align+axis*step+lane*outer] = val
								v[align+axis*step+lane*outer] = vval
							}
						}
						wantU, wantV := bytes.Clone(u), bytes.Clone(v)
						for _, edge := range []int{4, 8} {
							kind, b := 4, bl
							if edge == 4 {
								kind, b = 6, mb
							}
							loopFilterNarrow8(wantU, align+edge*step, step, outer, b, lim, thr, kind)
							loopFilterNarrow8(wantV, align+edge*step, step, outer, b, lim, thr, kind)
						}
						if !LoopFilterMacroInternalUV8(u[align:len(u)-13], v[align:len(v)-13], step, outer, mb, bl, lim, thr) {
							t.Fatal("eligible fused UV declined")
						}
						if !bytes.Equal(u, wantU) || !bytes.Equal(v, wantV) {
							t.Fatalf("v%v pitch%d align%d limits%v pattern%d", vertical, pitch, align, limits, pattern)
						}
					}
				}
			}
		}
	}
}
