package decoder
import("bytes";"fmt";"testing";"github.com/thesyncim/govpx/internal/vp8/common";"github.com/thesyncim/govpx/internal/vp8/dsp")
var uvFusionNativeSink byte
func uvFusionSeparateEdges(img *common.Image, row int, col int, uOff int, vOff int, mode *MacroblockMode, frameType common.FrameType, level byte, lfi *common.LoopFilterInfo) {
	skipLF := loopFilterSkipsInnerEdges(mode)
	hev := lfi.HEVThresh[lfi.HEVThreshLUT[frameType][level]]
	mblim := lfi.MBLimit[level]
	blim := lfi.BLimit[level]
	lim := lfi.Limit[level]

	if col > 0 {
		dsp.MBLoopFilterVerticalEdgeUV(img.U[uOff-4:], img.V[vOff-4:], img.UStride, mblim, lim, hev)
	}
	if !skipLF {
		dsp.LoopFilterVerticalEdgeUV(img.U[uOff:], img.V[vOff:], img.UStride, blim, lim, hev)
	}

	if row > 0 {
		dsp.MBLoopFilterHorizontalEdgeUV(img.U[uOff-4*img.UStride:], img.V[vOff-4*img.VStride:], img.UStride, mblim, lim, hev)
	}
	if !skipLF {
		dsp.LoopFilterHorizontalEdgeUV(img.U[uOff:], img.V[vOff:], img.UStride, blim, lim, hev)
	}
}

func BenchmarkVP8ChromaFilterNative(b *testing.B) {
 for _,pitch:=range []int{32,672} {for _,pattern:=range []string{"flat","ramp","smooth","noop"} {
 b.Run(fmt.Sprintf("pitch%d/%s",pitch,pattern),func(b *testing.B){
 u0,v0:=make([]byte,15*pitch+16),make([]byte,15*pitch+16)
 for y:=range 16 {for x:=range 16 {u,v:=byte(128),byte(123);switch pattern {case "ramp":u=byte(32+x+y);v=byte(48+x+y);case "smooth":u=byte(112+(x*3+y*5)%17);v=byte(101+(x*7+y*2)%17);case "noop":u=byte((y*16+x)*37+11);v=byte((y*16+x)*53+7)};u0[y*pitch+x]=u;v0[y*pitch+x]=v}}
 gotU,gotV:=bytes.Clone(u0),bytes.Clone(v0);wantU,wantV:=bytes.Clone(u0),bytes.Clone(v0)
 img:=common.Image{U:gotU,V:gotV,UStride:pitch,VStride:pitch};ref:=common.Image{U:wantU,V:wantV,UStride:pitch,VStride:pitch}
 var lfi common.LoopFilterInfo;common.InitLoopFilterInfo(&lfi,0);common.InitLoopFilterFrame(&lfi,32,common.LoopFilterFrameConfig{});mode:=MacroblockMode{};off:=8*pitch+8
 uvFusionSeparateEdges(&ref,1,1,off,off,&mode,common.InterFrame,32,&lfi)
 reset:=!bytes.Equal(wantU,u0)||!bytes.Equal(wantV,v0)
 b.ReportAllocs();for b.Loop() {if reset {for y:=4;y<16;y++ {copy(gotU[y*pitch+4:y*pitch+16],u0[y*pitch+4:y*pitch+16]);copy(gotV[y*pitch+4:y*pitch+16],v0[y*pitch+4:y*pitch+16])}};applyNormalLoopFilterChromaOnlyMB(&img,1,1,off,off,&mode,common.InterFrame,32,&lfi)}
 if !bytes.Equal(gotU,wantU)||!bytes.Equal(gotV,wantV){b.Fatal("fused UV caller differs from separate public edges")};uvFusionNativeSink=gotU[off]^gotV[off]
 })}}
}
