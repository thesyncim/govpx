from pathlib import Path
import subprocess,tarfile,io
snapshot=subprocess.check_output(['git','archive','20bc81cbbf68985f4619b6d69f3f3d60566ba013'])
root=Path('/private/tmp/govpx-next-filter-small');root.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:t.extractall(root)
name='internal/pixel/loopfilter_macro_internal_fused_arm64.go'
s=Path(name).read_text();needle='if f.ToBits().ReduceMax() != 0 {';assert s.count(needle)==4
parts=s.split(needle);s=parts[0]
for i,part in enumerate(parts[1:]):s+='if f.Abs().ToBits().ReduceMax() >= '+str(3 if i%2==0 else 4)+' {'+part
(root/name).write_text(s)
for variant in ['parent','candidate','small']:
 p=Path('/private/tmp/govpx-next-filter-'+('zero-'+variant if variant!='small' else 'small')+'/internal/vp8/decoder/picker_filter_native_bench_test.go')
 s=Path('internal/vp8/decoder/picker_filter_native_bench_test.go').read_text().replace('[]string{"flat", "smooth", "mixed", "noop"}','[]string{"flat", "ramp", "smooth", "mixed", "noop"}')
 s=s.replace('v := byte(112 + (x*3+y*5)%17)','v := byte(112 + (x*3+y*5)%17)\n if pattern=="ramp" {v=byte(32+x+y)}')
 p.write_text(s)
print(root)
