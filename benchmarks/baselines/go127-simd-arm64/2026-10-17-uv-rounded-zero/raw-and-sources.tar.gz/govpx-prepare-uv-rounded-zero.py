from pathlib import Path
import subprocess,tarfile,io
for v,sha in [('parent','42bac3ce697f71ae783a13b9c9a4fb540c29e581'),('candidate','42bac3ce697f71ae783a13b9c9a4fb540c29e581'),('assembly','691cd0512c4829d9ee40d483205dd223f9eb028d')]:
 root=Path('/private/tmp/govpx-next-uv-zero-'+v);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',sha]))) as t:t.extractall(root)
 if v=='candidate':
  f=root/'internal/pixel/loopfilter_uv_arith_simd.go';s=f.read_text().replace('import "simd/archsimd"','import ("simd/archsimd";"runtime")')
  needle='f := lfFilterDelta(outerF, p0c, q0c).Masked(need)';assert s.count(needle)==1
  s=s.replace(needle,needle+'''\n if runtime.GOARCH=="arm64" {
   bound:=uint8(4);if kind==6 {bound=3}
   if f.Abs().ToBits().ReduceMax()<bound {return}
 }''');f.write_text(s)
 print(root)
