from pathlib import Path
import json, hashlib, tarfile, io, statistics

base = Path('/private/tmp')
out = base / 'govpx-uv-zero-ready'
out.mkdir(exist_ok=True)
payload = {}
for p in base.glob('govpx-next-uv-zero*'):
    if p.is_file() and p.suffix in ['.py', '.json', '.log', '.txt', '.go']:
        payload[p.name] = p.read_bytes()
    if p.is_dir() and (p / 'summary.json').exists():
        for q in p.iterdir():
            if q.is_file() and q.suffix in ['.json', '.txt']:
                payload[p.name + '/' + q.name] = q.read_bytes()
for name in ['govpx-prepare-uv-rounded-zero.py', 'govpx-archive-uv-rounded-zero.py',
             'govpx-next-filter-small-fixed-packet-digests.log',
             'govpx-next-search-parent-fixed-packet-digests.log']:
    p = base / name
    if p.exists():
        payload[name] = p.read_bytes()
names = ['scripts/gensimd.go', 'internal/pixel/loopfilter_uv_arith_simd.go',
         'internal/pixel/loopfilter_uv_zero_arm64.go', 'internal/pixel/loopfilter_uv_zero_amd64.go',
         'internal/pixel/uv_zero_boundaries_arm64_test.go', 'internal/vp8/dsp/uv_zero_native_test.go',
         'cmd/govpx-bench/benchcmd/search_routing_fixed_digest_test.go']
for variant in ['parent', 'assembly', 'candidate']:
    root = base / ('govpx-next-uv-zero-' + variant)
    for name in names:
        p = root / name
        if p.exists():
            payload['sources/' + variant + '/' + name] = p.read_bytes()
fixtures = [payload['sources/' + v + '/internal/vp8/dsp/uv_zero_native_test.go'] for v in ['parent', 'assembly', 'candidate']]
assert fixtures[0] == fixtures[1] == fixtures[2]
for name in names:
    p = Path(name)
    if p.exists():
        payload['final-production/' + name] = p.read_bytes()
with tarfile.open(out / 'raw-and-sources.tar.gz', 'w:gz') as archive:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(data), 0
        archive.addfile(info, io.BytesIO(data))
(out / 'raw-sha256.json').write_text(json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(payload.items())}, indent=2) + '\n')
component = json.loads((base / 'govpx-next-uv-zero-confirm/summary.json').read_text())
public = json.loads((base / 'govpx-next-uv-zero-public-summary.json').read_text())
(out / 'component-summary.json').write_text(json.dumps(component, indent=2) + '\n')
(out / 'public-summary.json').write_text(json.dumps(public, indent=2) + '\n')
env = json.loads((base / 'govpx-filter-small-ready/environment.json').read_text())
env['parent'] = '42bac3ce697f71ae783a13b9c9a4fb540c29e581 (PR33 tested source)'
env['raw_file_count'] = len(payload)
bins = ['govpx-next-uv-zero-' + v + '.test' for v in ['parent', 'assembly', 'candidate']]
bins += ['govpx-next-uv-zero-candidate-final.test', 'govpx-next-uv-zero-candidate-bench', 'govpx-next-filter-small-bench', 'govpx-asm-bench']
env['binary_sha256'] = {n: hashlib.sha256((base / n).read_bytes()).hexdigest() for n in bins}
env['source_sha256'] = {n: hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names if Path(n).exists()}
env['scope'] = 'UV flat/gradient identity-correction shortcut. ARM instructions match timed prototype; AMD instructions match parent. Kernel and whole-codec evidence are independent.'
(out / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
wins = {n: x for n, x in component.items() if n.endswith(('/flat', '/ramp'))}
assert len(wins) == 16 and len(component) == 32
assert all(x['minimum_paired_speedup'] >= 1.5 for x in wins.values())
controls = {n: x for n, x in component.items() if n not in wins}
report = '''# ARM chroma rounded-zero correction shortcut

Native Apple M4 Max, Go1.27.2 archsimd, PGO off, GOMAXPROCS=1.
Parent is PR33 exact42bac3ce; pinned assembly691cd051. After masking the
canonical signed correction, return for kind6 |f|<=2 or kind4 |f|<=3.
Every primary/secondary and macro weighted correction then rounds to zero.
Unsigned ABS retains -128 as128, so it stays active. Existing wrapper requires
disjoint U/V allocations and logical rows. No carried edge state is omitted.
Larger corrections retain original arithmetic and store order.

Six fresh permutations of assembly/parent/current,150ms B.Loop. The identical
32-case fixture is copied to every snapshot: pitches32/672, both orientations,
internal/macro edges, flat/gradient/smooth/noop tiles, unaligned U3/V5 and minimal
readable8x8 windows with guards. Public DSP calls stay live through function
variables selected before B.Loop. Independent per-plane scalar oracles compare
the complete backing buffers. Only cases that change pixels restore both tiles
per iteration; identity cases repeat the same unchanged inputs. All samples
have zero bytes/op and zero allocations/op.

'''
report += f"The16 flat/gradient cases improve {min(x['speedup'] for x in wins.values()):.3f}–{max(x['speedup'] for x in wins.values()):.3f}x parent. All96 paired speedups are at least {int(min(x['minimum_paired_speedup'] for x in wins.values())*1000)/1000:.3f}x. The same cases improve {min(x['speedup_assembly'] for x in wins.values()):.3f}–{max(x['speedup_assembly'] for x in wins.values()):.3f}x ASM; all96 pairs beat ASM. These are fixture-scoped component wins, retained under AGENTS.md independently of whole-codec timing.\n\n"
report += f"The16 smooth/noop controls range {min(x['speedup'] for x in controls.values()):.4f}–{max(x['speedup'] for x in controls.values()):.4f}x parent; preserve every slower sample and regression. No general textured-filter speedup is claimed.\n\n"
report += 'Whole VP8 synthetic1280x720,realtime CPU8,2500kbps,one thread, six balanced three-way permutations:\n'
for frames in ['300', '60']:
    x = public[frames]
    report += f"\n* {frames}frames: {x['vs_parent_percent']:+.3f}% encode time versus parent ({x['faster_parent_pairs']}/6 faster), {x['vs_assembly_percent']:+.3f}% versus ASM ({x['faster_assembly_pairs']}/6 faster).\n"
report += '''
All23 non-timing result fields match and whole-codec allocations remain zero.
The ARM assembly gap remains open. No component gain is used as a whole-codec
claim. The two-round four-way luma/chroma diagnostic is archived separately;
it is not the acceptance run. Selective luma mask gating is not selected.

Correctness: full native ./..., original scalar filter tests,1280 public
boundary/alignment/plane-tail cases, exhaustive256 signed corrections in all16
lanes for both kinds, race/checkptr2, and six fixed-speed packet/drop digests
matching parent. Independent review confirms rounding, aliases and generator.
Initial snapshot full-suite failure was missing ignored upstream oracle source;
after linking the existing pinned source both tests and full suite passed.
Initial AMD build failure exposed an ARM-only ReduceMax method in a runtime
GOARCH branch; final architecture-specific helpers fix that compile issue.
Both initial failures and final passing logs remain archived.

Codegen: ARM final helper fully inlines and exactly matches the timed prototype's
410 instruction lines. AMD's constant-false helper removes the shortcut and its
464 instruction lines exactly match parent. Address prefixes alone are removed;
instruction counts are asserted nonzero. Rosetta checks correctness only.
Generator regeneration and final root PGO/fingerprint/build-selection checks
are recorded alongside their logs. No README changes or dependencies added.
'''
(out / 'REPORT.md').write_text(report)
print(out, len(payload))
