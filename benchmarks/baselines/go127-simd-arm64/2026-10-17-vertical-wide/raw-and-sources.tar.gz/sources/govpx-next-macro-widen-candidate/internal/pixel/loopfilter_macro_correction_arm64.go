// SPDX-License-Identifier: BSD-2-Clause
//go:build goexperiment.simd && arm64 && !purego

package pixel

import "simd/archsimd"

// Multiply signed byte corrections directly into int16 lanes. Current filter
// weights9/18/27 fit int8; wider helper arguments retain the original wrap path.
func lfMacroCorrection(f archsimd.Int8x16, c int16) archsimd.Int8x16 {
	var lo, hi archsimd.Int16x8
	if c >= -128 && c <= 127 {
		k := archsimd.BroadcastInt8x16(int8(c))
		lo = f.MulWidenLo(k)
		hi = f.HiToLo().MulWidenLo(k)
	} else {
		k := archsimd.BroadcastInt16x8(c)
		lo = f.ExtendLo8ToInt16().Mul(k)
		hi = highBytes(f.ToBits()).BitsToInt8().ExtendLo8ToInt16().Mul(k)
	}
	bias := archsimd.BroadcastInt16x8(63)
	return lfJoinSigned(lfTruncSigned(filterShift7(lo.Add(bias))), lfTruncSigned(filterShift7(hi.Add(bias))))
}
