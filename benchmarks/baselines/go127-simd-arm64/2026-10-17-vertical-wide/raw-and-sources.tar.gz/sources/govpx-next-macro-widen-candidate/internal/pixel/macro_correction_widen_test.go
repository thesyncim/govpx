//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import (
	"simd/archsimd"
	"testing"
)

func TestMacroCorrectionSignedRange(t *testing.T) {
	if !Enabled {
		t.Skip("SIMD unavailable")
	}
	for _, c := range []int16{-32768, -129, -128, -1, 0, 1, 9, 18, 27, 127, 128, 255, 32767} {
		for base := -128; base < 128; base += 16 {
			var in, out [16]int8
			for i := range in {
				in[i] = int8(base + i)
			}
			lfMacroCorrection(archsimd.LoadInt8x16Array(&in), c).StoreArray(&out)
			for i, f := range in {
				want := int8((int16(f)*c + 63) >> 7)
				if out[i] != want {
					t.Fatalf("f%d c%d got%d want%d", f, c, out[i], want)
				}
			}
		}
	}
}
