// SPDX-License-Identifier: BSD-2-Clause
//go:build goexperiment.simd && amd64 && !purego

package pixel

import "simd/archsimd"

func lfMacroCorrection(f archsimd.Int8x16, c int16) archsimd.Int8x16 {
	// The 9/18/27 corrections fit int8 after rounding (maximum +/-27).
	k, bias := archsimd.BroadcastInt16x8(c), archsimd.BroadcastInt16x8(63)
	lo := lfTruncSigned(filterShift7(f.ExtendLo8ToInt16().Mul(k).Add(bias)))
	hi := lfTruncSigned(filterShift7(highBytes(f.ToBits()).BitsToInt8().ExtendLo8ToInt16().Mul(k).Add(bias)))
	return lfJoinSigned(lo, hi)
}
