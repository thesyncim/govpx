import pathlib,subprocess,tarfile,io,json
repo=pathlib.Path('/Users/thesyncim/GolandProjects/govpx')
roots={v:pathlib.Path('/private/tmp/govpx-next-vertical-edges-'+v) for v in ['parent','candidate']}
archive=subprocess.check_output(['git','archive','HEAD'],cwd=repo)
for root in roots.values():
 root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(archive)) as t:
  t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
p=roots['candidate']/'internal/pixel/loopfilter_macro_internal_fused_arm64.go'
s=p.read_text();start=s.index('func loopFilterMacroInternalFusedVertical(')
loop=s.index('\tfor edge := 8; edge <= 16; edge += 4 {',start)
body_start=s.index('{',loop)+1;depth=1;i=body_start
while depth:
 depth+=(s[i]=='{')-(s[i]=='}');i+=1
body=s[body_start:i-1]
marker='\n\t\tif edge == 16 {\n\t\t\tbreak\n\t\t}'
assert body.count(marker)==1
compute,carry=body.split(marker)
replacement='\n'.join('\t{\n\t\tconst edge = '+str(edge)+compute+(carry if edge<16 else '')+'\n\t}' for edge in [8,12,16])
p.write_text(s[:loop]+replacement+s[i:])
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p)],check=True)
print(json.dumps({k:str(v) for k,v in roots.items()}))
