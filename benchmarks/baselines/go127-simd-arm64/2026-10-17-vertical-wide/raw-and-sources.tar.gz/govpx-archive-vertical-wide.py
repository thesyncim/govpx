from pathlib import Path
import json,hashlib,tarfile,io
base=Path('/private/tmp');out=base/'govpx-vertical-wide-ready';out.mkdir(exist_ok=True);payload={}
for prefix in ['govpx-next-macro-widen','govpx-next-vertical-edges','govpx-next-vertical-wide','govpx-post-gather-vp8-profile','govpx-next-horizontal-edges']:
 for p in base.glob(prefix+'*'):
  if p.is_file() and p.suffix in ['.py','.json','.txt','.log','.pgo','.go']:payload[p.name]=p.read_bytes()
  if p.is_dir() and (p/'summary.json').exists():
   for q in p.iterdir():
    if q.is_file() and q.suffix in ['.json','.txt']:payload[p.name+'/'+q.name]=q.read_bytes()
for name in ['govpx-prepare-vertical-edges.py','govpx-prepare-vertical-wide.py','govpx-integrate-vertical-wide.py','govpx-archive-vertical-wide.py','govpx-summarize-public.py','govpx-next-gather-unrolled-fixed-packet-digests.log','govpx-next-gather-unrolled-packet-equivalence.json']:
 payload[name]=(base/name).read_bytes()
names=['internal/pixel/goav1_loopfilter_bytes_simd.go','internal/pixel/loopfilter_macro_correction_arm64.go','internal/pixel/loopfilter_macro_correction_amd64.go','internal/pixel/macro_correction_widen_test.go','internal/pixel/loopfilter_macro_internal_fused_arm64.go','internal/pixel/loopfilter_columns_wide20_arm64.go','internal/pixel/loopfilter_macro_internal_arm64.go','internal/pixel/loopfilter_macro_internal_arm64_test.go','internal/vp8/decoder/picker_filter_native_bench_test.go','cmd/govpx-bench/benchcmd/search_routing_fixed_digest_test.go','scripts/gensimd.go']
for variant in ['govpx-next-macro-widen-candidate','govpx-next-vertical-edges-parent','govpx-next-vertical-edges-candidate','govpx-next-vertical-wide-candidate','govpx-next-horizontal-edges-candidate']:
 for name in names:
  p=base/variant/name
  if p.exists():payload['sources/'+variant+'/'+name]=p.read_bytes()
with tarfile.open(out/'raw-and-sources.tar.gz','w:gz') as t:
 for name,data in sorted(payload.items()):
  info=tarfile.TarInfo(name);info.size,info.mtime=len(data),0;t.addfile(info,io.BytesIO(data))
(out/'raw-sha256.json').write_text(json.dumps({n:hashlib.sha256(d).hexdigest() for n,d in sorted(payload.items())},indent=2)+'\n')
component=json.loads((base/'govpx-next-vertical-wide-confirm/summary.json').read_text());public=json.loads((base/'govpx-next-vertical-wide-public-summary.json').read_text())
assert len(component)==10 and all(x['faster_parent_pairs']==6 for x in component.values())
(out/'component-summary.json').write_text(json.dumps(component,indent=2)+'\n');(out/'public-summary.json').write_text(json.dumps(public,indent=2)+'\n')
bins=['govpx-next-macro-widen-parent.test','govpx-next-macro-widen-assembly.test','govpx-next-vertical-edges-candidate.test','govpx-next-vertical-wide-candidate.test','govpx-next-vertical-wide-regenerated.test','govpx-next-vertical-wide-bench','govpx-next-gather-unrolled-root-bench','govpx-asm-bench']
(out/'environment.json').write_text(json.dumps({'cpu':'Apple M4 Max','compiler':'Go1.27.2 darwin/arm64 archsimd','pgo':'off','goprocs':1,'parent':'34b00fb49753cec53def480c97d1b6825d426d31','assembly':'691cd0512c4829d9ee40d483205dd223f9eb028d','raw_members':len(payload),'final_root_source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in ['internal/pixel/loopfilter_macro_internal_fused_arm64.go','internal/pixel/loopfilter_columns_wide20_arm64.go','scripts/gensimd.go','cmd/govpx-bench/default.pgo','cmd/govpx-bench/default.pgo.sources.sha256']},'binary_sha256':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in bins}},indent=2)+'\n')
report='''# ARM vertical filter wide row loads

Native Apple M4 Max, Go1.27.2 archsimd, PGO off, GOMAXPROCS1.
Parent PR35 exact34b00fb4, pinned old assembly691cd051. Fixed internal edges
8/12/16 retain all dependent arithmetic/carries and exact final packed stores.
Initial column transpose uses low8 bytes of16-byte vector row loads; incoming
packets select words1/2/3 from vector loads at column4. Existing wrapper proves
all20 columns of16 disjoint rows. Every read remains within that exact window,
including pitch20, minimal slices and unaligned starts. No padding assumption.

Fresh six balanced parent/ASM/current permutations, with unrolled narrow-load
variant first/last as a fourth control;150ms per10 public Picker fixtures.
All60 paired samples improve versus parent, zero B/op and allocs/op. Fixtures
reset the entire union of read windows within B.Loop, compare full buffers with
the separate public edge operations, and retain observable output; independent
pixel tests use scalar filter equations.

'''
for n,x in component.items():report+=f"* {n}: {x['speedup']:.4f}x parent, {x['speedup_unrolled']:.4f}x unrolled narrow loads, {x['speedup_assembly']:.4f}x assembly; {x['faster_parent_pairs']}/6 faster parent and {x['faster_assembly_pairs']}/6 faster assembly.\n"
report+='''
This is a smaller consistent component improvement, not a new1.5x gain.
Previously accepted >=1.5x gather and other component wins remain intact,
independently of whole-encoder timing. Active textured filters still trail
assembly; flat/ramp/noop controls beat assembly. Do not generalize their ratio
to textured work or the complete codec.

Whole synthetic720p VP8, realtimeCPU8,2500kbps,one thread, six fresh balanced
three-way permutations, all23 non-timing result fields exact and zero allocations:
'''
for f,x in public.items():report+=f"\n* {f} frames: {x['vs_parent_percent']:+.4f}% encode time versus parent ({x['faster_parent_pairs']}/6 faster), {x['vs_assembly_percent']:+.4f}% versus assembly ({x['faster_assembly_pairs']}/6 faster).\n"
report+='''
Validation: complete native ./... PASS; existing7200 fusion cases plus640
zero-correction/later-edge cases, decline guards, race/checkptr2 PASS; six
fixed-speed packet/drop digests exactly match the previously validated PR35
results. Final root refreshed PGO, noasm/build-selection/precommit and full
suite logs are included. Validation and raw logs are included. The regenerated vertical hot body exactly
matches all698 timed instruction words and self-relative rendered branches.
Calls to initial-load/final-store helpers and cold stack growth remain; counts
are diagnostic rather than speed/acceptance rules. AMD generated source and
ARM horizontal function remain byte-identical to parent. Independent review
symbolically checked every lane of both transpose schedules and carried values.

Rejected probes and qualitative profile remain preserved in this archive:
direct signed widening multiply for macro coefficients9/18/27, with generic
int16 fallback for full helper contract, passed all256signed bytes across13
coefficients/extreme ranges. Two balanced100ms diagnostics show no useful
active-filter gain; no production promotion. Fixed-edge narrow-load unroll
alone gives about1–5% diagnostically; wide-load winner is confirmed freshly.
A separate horizontal fixed-edge unroll, based on the accepted vertical variant,
shows only mixed/small active-work differences in two diagnostic rounds
(0.991–1.015x textured,1.013–1.039x identity controls). It is preserved without
production promotion or a claim of a new1.5x gain.
The first wide-load compile had an unused first-edge variable; fixed retry is
retained alongside the failure. Every timing sample and outlier is included.

The post-gather1800-frame profile is qualitative:12.99s samples/13.42s duration,
vertical fusion12.24% cumulative, horizontal6.08%, token writer6.85%, DCT4.54%.
Profile percentages do not establish causal or additive speedups. No concurrent
builds/profiles during timings; independent C/native x64 CI runs on other hosts.
No README, dependency, handwritten assembly or production cgo changes.
'''
(out/'REPORT.md').write_text(report);print(out,len(payload))
