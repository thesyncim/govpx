from pathlib import Path
import shutil,subprocess
base=Path('/private/tmp/govpx-next-vertical-edges-candidate')
root=Path('/private/tmp/govpx-next-vertical-wide-candidate')
shutil.copytree(base,root,dirs_exist_ok=True)
p=root/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=p.read_text()
start=s.index('func loopFilterMacroInternalFusedVertical(')
head=s[:start];v=s[start:]
v=v.replace('loadLFColumns[[8]byte](p, 0, outer, 16)','loadLFColumnsWide20(p, outer)',1)
for edge in [4,8,12]:
 marker=('\t\tedge := 4' if edge==4 else '\t\tconst edge = '+str(edge))
 a=v.index('\t\tptr := unsafe.Add',v.index(marker));b=v.index('\n\t\ta0, a1 :=',a)
 word=(edge+4-4)//4;op='Even' if word%2==0 else 'Odd';join='Lo' if word<2 else 'Hi'
 lines=['\t\t// The fused wrapper proves all twenty columns; wide loads at column four remain in bounds.', '\t\tptr := unsafe.Add(unsafe.Pointer(unsafe.SliceData(p)), 4)']
 for i in range(4):
  lines+=['\t\t{']
  for j,row in enumerate([i,i+4,i+8,i+12]):lines.append(f'\t\t\tw{j} := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ptr, {row}*outer))).ReshapeToUint32s()')
  lines.extend([f'\t\t\tw01, w23 := w0.Interleave{op}(w1).ReshapeToUint64s(), w2.Interleave{op}(w3).ReshapeToUint64s()',f'\t\t\tr{i} = w01.Interleave{join}(w23).ReshapeToUint16s()', '\t\t}'])
 lines.insert(2,'\t\tvar r0, r1, r2, r3 archsimd.Uint16x8')
 v=v[:a]+'\n'.join(lines)+v[b:]
v=v.replace('\n\t\tedge := 4\n','\n',1)
p.write_text(head+v)
helper=(root/'internal/pixel/loopfilter_columns_arm64.go').read_text()
a=helper.index('func loadLFColumns16(');fn=helper[a:].replace('func loadLFColumns16(p []byte, off, pitch int)','func loadLFColumnsWide20(p []byte, pitch int)',1).replace('unsafe.Add(unsafe.Pointer(unsafe.SliceData(p)), off)','unsafe.Pointer(unsafe.SliceData(p))',1)
for i in range(8):
 old=f'r{i} := archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(ptr, {i}*pitch))).SetElem(1, *(*uint64)(unsafe.Add(ptr, {i+8}*pitch))).ReshapeToUint32s()'
 new=f'r{i} := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ptr, {i}*pitch))).ReshapeToUint64s().InterleaveLo(archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ptr, {i+8}*pitch))).ReshapeToUint64s()).ReshapeToUint32s()'
 assert old in fn;fn=fn.replace(old,new)
(root/'internal/pixel/loopfilter_columns_wide20_arm64.go').write_text('//go:build goexperiment.simd && arm64 && !purego\n\npackage pixel\n\nimport ("simd/archsimd"; "unsafe")\n\n// loadLFColumnsWide20 requires sixteen disjoint rows of twenty readable bytes.\n'+fn)
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p),str(root/'internal/pixel/loopfilter_columns_wide20_arm64.go')],check=True)
print(root)
