package govpx

import "testing"

func TestFullPelSADBelowFourThresholds(t *testing.T) {
	for mode := 0; mode < 3; mode++ {
		src := testImage(64, 64)
		fillImage(src, 17, 90, 170)
		ref := testVP8Frame(t, 64, 64, 17, 90, 170)
		for y := range 64 {
			for x := range 64 {
				if mode == 1 {
					src.Y[y*src.YStride+x] = byte(y*37 + x*19 + 11)
					ref.Img.Y[y*ref.Img.YStride+x] = byte(y*17 + x*53 + 29)
				}
				if mode == 2 {
					src.Y[y*src.YStride+x] = 0
					ref.Img.Y[y*ref.Img.YStride+x] = 255
				}
			}
		}
		ctx := newFullPelSearchCtx(sourceImageFromPublic(src), &ref.Img, 1, 1)
		rows, cols := [4]int{-1, 0, 1, 0}, [4]int{0, -1, 0, 1}
		var full [4]uint32
		for i := range full {
			for y := range 16 {
				for x := range 16 {
					a := int(src.Y[(16+y)*src.YStride+16+x])
					b := int(ref.Img.Y[(16+rows[i]+y)*ref.Img.YStride+16+cols[i]+x])
					d := a - b
					if d < 0 {
						d = -d
					}
					full[i] += uint32(d)
				}
			}
		}
		cutoffs := []int{-int(^uint(0)>>1) - 1, -1, 0, 1, 1024, 4096, 4097, 65280, 65281, int(^uint(0) >> 1)}
		for _, v := range full {
			cutoffs = append(cutoffs, int(v)-1, int(v), int(v)+1)
		}
		for _, cutoff := range cutoffs {
			var got [4]uint32
			if !ctx.fullPelSADBelow4(rows[0], cols[0], rows[1], cols[1], rows[2], cols[2], rows[3], cols[3], cutoff, &got) {
				t.Fatal("eligible windows declined")
			}
			for i, g := range got {
				if int(full[i]) < cutoff {
					if g != full[i] {
						t.Fatalf("mode%d cutoff%d ref%d got%d full%d", mode, cutoff, i, g, full[i])
					}
				} else if int(g) < cutoff || g > full[i] {
					t.Fatalf("invalid witness mode%d cutoff%d ref%d got%d full%d", mode, cutoff, i, g, full[i])
				}
			}
			// All later best costs can only decrease. A witnessed loser must remain
			// a loser; below-cutoff exact sums preserve strict ties and MV-cost use.
			for _, best := range []int{cutoff, cutoff / 2, -1} {
				if best > cutoff {
					continue
				}
				for i, g := range got {
					if (int(g) < best) != (int(full[i]) < best) {
						t.Fatalf("precheck changed cutoff%d best%d ref%d", cutoff, best, i)
					}
				}
			}
		}
		out := [4]uint32{11, 22, 33, 44}
		saved := out
		if ctx.fullPelSADBelow4(1<<20, 0, 0, 0, 0, 0, 0, 0, 0, &out) || out != saved {
			t.Fatal("declined reference changed output")
		}
	}
}

func TestFullPelSADBelowFourClampedAndDeclines(t *testing.T) {
 src:=testImage(17,16);fillImage(src,17,90,170)
 for y:=range 16 {src.Y[y*src.YStride+16]=77}
 ref:=testVP8Frame(t,17,16,17,90,170)
 source:=sourceImageFromPublic(src)
 for _,cutoff:=range []int{0,1,4096,65281} {
  fullCtx:=newFullPelSearchCtx(source,&ref.Img,0,1)
  ctx:=newFullPelSearchCtx(source,&ref.Img,0,1)
  if ctx.srcFull {t.Fatal("fixture must clamp partial source")}
  var full,got [4]uint32
  if !fullCtx.fullPelSADFull4(-16,-16,-15,-16,-14,-16,-13,-16,&full)||!ctx.fullPelSADBelow4(-16,-16,-15,-16,-14,-16,-13,-16,cutoff,&got) {t.Fatal("legal border windows declined")}
  if !ctx.srcClamped||ctx.srcScratch!=fullCtx.srcScratch {t.Fatal("source clamp state changed")}
  for i,g:=range got {if int(full[i])<cutoff {if g!=full[i] {t.Fatalf("clamped cutoff%d ref%d got%d full%d",cutoff,i,g,full[i])}} else if int(g)<cutoff||g>full[i] {t.Fatalf("clamped invalid witness cutoff%d ref%d",cutoff,i)}}
 }
 for bad:=range 4 {
  ctx:=newFullPelSearchCtx(source,&ref.Img,0,1)
  rows:=[4]int{};rows[bad]=1<<20
  out:=[4]uint32{11,22,33,44};saved:=out
  if ctx.fullPelSADBelow4(rows[0],0,rows[1],0,rows[2],0,rows[3],0,0,&out)||out!=saved||ctx.srcClamped {t.Fatalf("invalid ref%d changed outputs/cache",bad)}
 }
 ctx:=newFullPelSearchCtx(source,&ref.Img,0,1);ctx.refYFullP=nil
 out:=[4]uint32{11,22,33,44};saved:=out
 if ctx.fullPelSADBelow4(0,0,0,0,0,0,0,0,0,&out)||out!=saved||ctx.srcClamped {t.Fatal("missing reference changed outputs/cache")}
}
