import os,json,subprocess,statistics
from pathlib import Path
variants=['parent','all','4096'];env=dict(os.environ,GOMAXPROCS='1');rows=[];ref=None
ignored={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns'}
for r,order in enumerate([variants,list(reversed(variants))],1):
 for v in order:
  args=['/private/tmp/govpx-next-search-limited-'+v+'-bench','-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
  x=json.loads(subprocess.check_output(args,env=env,text=True));semantic={k:z for k,z in x.items() if k not in ignored}
  if ref is None:ref=semantic
  assert semantic==ref,(v,{k:(ref[k],semantic[k]) for k in ref if ref[k]!=semantic[k]})
  rows.append({'round':r,'variant':v,'result':x});Path('/private/tmp/govpx-next-search-limited-diagnostic.json').write_text(json.dumps({'samples':rows},indent=2)+'\n');print(v,'round',r,'done',flush=True)
summary={v:{'median_ns':statistics.median(x['result']['ns_per_frame'] for x in rows if x['variant']==v),'samples':[x['result']['ns_per_frame'] for x in rows if x['variant']==v]} for v in variants}
for v in variants:summary[v]['speedup_vs_parent']=summary['parent']['median_ns']/summary[v]['median_ns']
Path('/private/tmp/govpx-next-search-limited-diagnostic-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
