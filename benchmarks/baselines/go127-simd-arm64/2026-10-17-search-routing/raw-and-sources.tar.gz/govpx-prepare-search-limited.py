from pathlib import Path
import subprocess,tarfile,io
snapshot=subprocess.check_output(['git','archive','HEAD'])
for variant in ['parent','all','4096']:
 root=Path('/private/tmp/govpx-next-search-limited-'+variant);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:t.extractall(root)
 if variant=='parent':continue
 f=root/'vp8_encoder_inter_motion_cost.go';s=f.read_text();a=s.index('func (c *fullPelSearchCtx) fullPelSADFull4(');b=s.index('\nfunc ',a+5);body=s[a:b].replace('fullPelSADFull4(', 'fullPelSADBelow4(',1).replace('out *[4]uint32) bool {','cutoff int, out *[4]uint32) bool {',1)
 old='\tdsp.SAD16x16x4PtrFast(srcPtr, srcStride, refPtr0, refPtr1, refPtr2, refPtr3, c.refYStride, out)'
 limited='''\tlimit := int32(-1)
 if cutoff > 0 { limit = int32(min(cutoff-1, 65280)) }
 limits := [4]int32{limit,limit,limit,limit}
 dsp.SAD16x16x4LimitPtrFast(srcPtr, srcStride, refPtr0, refPtr1, refPtr2, refPtr3, c.refYStride, &limits, out)'''
 assert body.count(old)==1
 if variant=='4096': limited='\tif cutoff > 4096 {\n'+old+'\n } else {\n'+limited+'\n }'
 body=body.replace(old,limited)
 comment='''// fullPelSADBelow4 keeps exact sums below cutoff and returns threshold
// witnesses otherwise. Search compares SAD strictly against a best cost that
// can only decrease within the batch; every discarded witness also discards
// the original full sum. Do not use witnesses as exact scores.
'''
 f.write_text(s[:b]+'\n'+comment+body+s[b:])
 for name,bound in [('vp8_encoder_motion_search.go','bestWalkCost'),('vp8_encoder_motion_search_kernel.go','bestCost')]:
  f=root/name;lines=f.read_text().splitlines()
  for i,line in enumerate(lines):
   if 'ctx.fullPelSADFull4(' in line:lines[i]=line.replace('ctx.fullPelSADFull4(', 'ctx.fullPelSADBelow4(').replace(', &sad4)',', '+bound+', &sad4)')
  f.write_text('\n'.join(lines)+'\n')
