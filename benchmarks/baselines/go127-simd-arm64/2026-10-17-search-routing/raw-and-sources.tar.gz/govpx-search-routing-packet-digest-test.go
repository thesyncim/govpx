package benchcmd

import (
 "crypto/sha256"
 "encoding/binary"
 "testing"
)

func TestSearchRoutingPacketDigest(t *testing.T) {
 for _,tc:=range []struct{w,h,n int;flat bool}{{17,16,60,false},{64,64,120,false},{64,64,120,true},{320,180,120,false},{1280,720,60,false},{1280,720,300,false}} {
  cfg:=benchConfig{Width:tc.w,Height:tc.h,Frames:tc.n,FPS:30,BitrateKbps:2500,Mode:"realtime",CpuUsed:8,Threads:1}
  deadline,_,err:=benchmarkDeadline(cfg.Mode);if err!=nil {t.Fatal(err)}
  enc,err:=newBenchmarkEncoder(cfg,deadline);if err!=nil {t.Fatal(err)}
  packet:=make([]byte,max(4096,tc.w*tc.h*6));h:=sha256.New();outputs,drops:=0,0
  for i:=range tc.n {
   frame:=makeBenchmarkFrame(tc.w,tc.h,i)
   if tc.flat {for j:=range frame.Y {frame.Y[j]=128};for j:=range frame.U {frame.U[j]=128};for j:=range frame.V {frame.V[j]=128}}
   result,err:=enc.EncodeInto(packet,frame,uint64(i),1,0);if err!=nil {t.Fatal(err)}
   var header [17]byte;binary.LittleEndian.PutUint64(header[:8],uint64(i));binary.LittleEndian.PutUint64(header[8:16],uint64(len(result.Data)))
   if result.Dropped {header[16]=1;drops++} else {outputs++}
   h.Write(header[:]);h.Write(result.Data)
  }
  t.Logf("PACKET_DIGEST %dx%d/%d/flat%v sha256=%x outputs=%d drops=%d",tc.w,tc.h,tc.n,tc.flat,h.Sum(nil),outputs,drops)
 }
}
