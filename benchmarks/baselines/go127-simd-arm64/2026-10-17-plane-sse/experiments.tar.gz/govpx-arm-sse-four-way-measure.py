import os,subprocess
from pathlib import Path
env=dict(os.environ,GOMAXPROCS='1',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='root-arm-sse-four-way')
names=['assembly','parent','safe','proved'];bins=['/private/tmp/govpx-arm-sse-windows-assembly.test','/private/tmp/govpx-arm-sse-windows-parent.test','/private/tmp/govpx-arm-sse-windows-candidate.test','/private/tmp/govpx-arm-sse-proved.test'];orders=[[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2],[3,2,1,0],[0,3,2,1],[1,0,3,2],[2,1,0,3]]
for name in names:Path('/private/tmp/govpx-arm-sse-four-way-'+name+'.txt').write_text('')
for r,order in enumerate(orders):
 for i in order:
  args=['/Users/thesyncim/.codex/bin/project-env',bins[i],'-test.run=^$','-test.bench=^BenchmarkSSE16RowsNative$','-test.benchtime=150ms','-test.count=1','-test.cpu=1','-test.benchmem']
  with Path('/private/tmp/govpx-arm-sse-four-way-'+names[i]+'.txt').open('a') as f:
   f.write('# round '+str(r+1)+'\n');f.flush();subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('ARM SSE four-way round',r+1,'done',flush=True)
