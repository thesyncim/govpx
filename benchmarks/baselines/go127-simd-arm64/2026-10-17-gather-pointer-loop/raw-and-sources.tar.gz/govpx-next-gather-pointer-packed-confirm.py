import os,subprocess,pathlib,json,re,statistics
out=pathlib.Path('/private/tmp/govpx-next-gather-pointer-packed-confirm');out.mkdir(exist_ok=True)
bins={v:'/private/tmp/govpx-next-gather-pointer-'+v+'-packed-confirm.test' for v in ['parent','assembly','candidate']}
env=dict(os.environ,GOMAXPROCS='1');rows={v:{} for v in bins}
orders=[['parent','assembly','candidate'],['assembly','candidate','parent'],['candidate','parent','assembly'],['parent','candidate','assembly'],['candidate','assembly','parent'],['assembly','parent','candidate']]
for r,order in enumerate(orders,1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkGatherPackedPredictionNative$','-test.benchtime=150ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  matches=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(matches)==8,len(matches)
  for name,ns,b,a in matches:
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns))
 print('round',r,'done',flush=True)
summary={k:{'samples':{v:rows[v][k] for v in bins},'speedup':statistics.median(rows['parent'][k])/statistics.median(rows['candidate'][k]),'minimum_paired_speedup':min(a/b for a,b in zip(rows['parent'][k],rows['candidate'][k])),'speedup_assembly':statistics.median(rows['assembly'][k])/statistics.median(rows['candidate'][k]),'faster_parent_pairs':sum(a>b for a,b in zip(rows['parent'][k],rows['candidate'][k])),'faster_assembly_pairs':sum(a>b for a,b in zip(rows['assembly'][k],rows['candidate'][k]))} for k in rows['parent']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
