from pathlib import Path
root=Path('/private/tmp/govpx-next-gather-pointer')
header='''//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel
import("simd/archsimd";"unsafe")

// Read-only rows may repeat or overlap. Output must not overlap either input.
// Limit stride arithmetic before forming exact row windows. Invalid pointer
// arguments decline so the original public path retains its panic behavior.
'''
body=''
for width in [16,8]:
 body+=f'''func Gather{width}PtrFast(src *byte, ss int, pred *byte, ps int, out *int16) bool {{
 if !Enabled || src==nil || pred==nil || out==nil || (uint(ss)|uint(ps))>>48!=0 {{return false}}
 sp,pp,op:=unsafe.Pointer(src),unsafe.Pointer(pred),unsafe.Pointer(out)
 for block:=range {width//4} {{
  y:=block*4
'''
 for row in [0,2]:
  body+=' {\n'
  if width==16:
   for i in [0,1]:
    body+=f'a{i}:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,(y+{row+i})*ss)))\nb{i}:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(pp,(y+{row+i})*ps)))\n'
   body+='''lo0:=widen8(a0).Sub(widen8(b0)).ToBits().ReshapeToUint64s()
lo1:=widen8(a1).Sub(widen8(b1)).ToBits().ReshapeToUint64s()
hi0:=widenHi8(a0).Sub(widenHi8(b0)).ReshapeToUint64s()
hi1:=widenHi8(a1).Sub(widenHi8(b1)).ReshapeToUint64s()
'''
   for offset,expr in [(0,'lo0.InterleaveLo(lo1)'),(16,'lo0.InterleaveHi(lo1)'),(32,'hi0.InterleaveLo(hi1)'),(48,'hi0.InterleaveHi(hi1)')]:
    body+=f'{expr}.ReshapeToUint16s().BitsToInt16().StoreArray((*[8]int16)(unsafe.Add(op,(block*64+{row*4+offset})*2)))\n'
  else:
   for name,pointer,stride in [('a','sp','ss'),('b','pp','ps')]:
    body+=f'{name}:=archsimd.Uint64x2{{}}.SetElem(0,*(*uint64)(unsafe.Add({pointer},(y+{row})*{stride}))).SetElem(1,*(*uint64)(unsafe.Add({pointer},(y+{row+1})*{stride}))).ReshapeToUint8s()\n'
   body+='''lo:=widen8(a).Sub(widen8(b)).ToBits().ReshapeToUint64s()
hi:=widenHi8(a).Sub(widenHi8(b)).ReshapeToUint64s()
'''
   for offset,expr in [(0,'lo.InterleaveLo(hi)'),(16,'lo.InterleaveHi(hi)')]:
    body+=f'{expr}.ReshapeToUint16s().BitsToInt16().StoreArray((*[8]int16)(unsafe.Add(op,(block*32+{row*4+offset})*2)))\n'
  body+=' }\n'
 body+=' }\n return true\n}\n'
(root/'internal/pixel/gather_pointer_simd.go').write_text(header+body)
generic='//go:build !goexperiment.simd || (!arm64 && !amd64) || purego\n\npackage pixel\n'
for width in [16,8]:generic+=f'func Gather{width}PtrFast(_, _unused *byte, _ss int, _ps int, _out *int16) bool {{return false}}\n'
# Keep signatures in the same parameter order as the SIMD entries.
generic=generic.replace('(_, _unused *byte, _ss int, _ps int, _out *int16)', '(_ *byte, _ss int, _unused *byte, _ps int, _out *int16)')
(root/'internal/pixel/gather_pointer_generic.go').write_text(generic)
p=root/'internal/vp8/dsp/residual_gather_other.go';s=p.read_text()
for width in [16,8]:
 marker=f'func ResidualGather{width}x{width}PtrFast(src *byte, srcStride int, pred *byte, predStride int, out *int16) {{'
 assert s.count(marker)==1
 s=s.replace(marker,marker+f'\n if pixel.Gather{width}PtrFast(src,srcStride,pred,predStride,out) {{return}}',1)
p.write_text(s)
print(root)
