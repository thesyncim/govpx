from pathlib import Path
import json, hashlib, tarfile, io
base = Path('/private/tmp')
out = base / 'govpx-gather-pointer-ready'
out.mkdir(exist_ok=True)
payload = {}
for p in base.glob('govpx-next-gather-pointer*'):
    if p.is_file() and p.suffix in ['.py', '.json', '.txt', '.log']:
        payload[p.name] = p.read_bytes()
    if p.is_dir() and (p / 'summary.json').exists():
        for q in p.iterdir():
            if q.is_file() and q.suffix in ['.json', '.txt']:
                payload[p.name + '/' + q.name] = q.read_bytes()
for name in ['govpx-prepare-gather-pointer.py', 'govpx-gather-pointer-native-test.go', 'govpx-gather-pointer-full-native-test.go', 'govpx-archive-gather-pointer.py', 'govpx-summarize-public.py']:
    payload[name] = (base / name).read_bytes()
names = ['internal/pixel/gather_pointer_simd.go', 'internal/pixel/gather_pointer_generic.go',
         'internal/pixel/gather_pointer_test.go', 'internal/pixel/gather_pointer_disabled_amd64_test.go',
         'internal/vp8/dsp/residual_gather_other.go', 'internal/vp8/dsp/gather_pointer_native_test.go',
         'internal/vp8/dsp/gather_pointer_rows_test.go', 'internal/pixel/kernels_simd.go']
roots = {'parent': base / 'govpx-next-uv-fusion-parent', 'assembly': base / 'govpx-next-uv-zero-assembly', 'candidate': base / 'govpx-next-gather-pointer'}
for variant, root in roots.items():
    for name in names:
        p = root / name
        if p.exists(): payload['sources/' + variant + '/' + name] = p.read_bytes()
for name in names:
    p = Path(name)
    if p.exists(): payload['checkpoint-production/' + name] = p.read_bytes()
with tarfile.open(out / 'raw-and-sources.tar.gz', 'w:gz') as archive:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name); info.size, info.mtime = len(data), 0
        archive.addfile(info, io.BytesIO(data))
(out / 'raw-sha256.json').write_text(json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(payload.items())}, indent=2) + '\n')
component = {}
for study in ['confirm', 'packed-confirm']:
    data = json.loads((base / ('govpx-next-gather-pointer-' + study) / 'summary.json').read_text())
    assert not set(component).intersection(data)
    component.update(data)
assert len(component) == 18 and all(x['speedup'] >= 1.5 for x in component.values())
public = json.loads((base / 'govpx-next-gather-pointer-public-summary.json').read_text())
(out / 'component-summary.json').write_text(json.dumps(component, indent=2) + '\n')
(out / 'public-summary.json').write_text(json.dumps(public, indent=2) + '\n')
env = {'cpu': 'Apple M4 Max', 'compiler': 'Go1.27.2 darwin/arm64 GOEXPERIMENT=simd',
       'parent': '03afac7c47a7ce3e7f52d0925308f95932b2a9df', 'assembly': '691cd0512c4829d9ee40d483205dd223f9eb028d',
       'pgo': 'off', 'goprocs': 1, 'threads': 1, 'raw_members': len(payload)}
bins = ['govpx-next-gather-pointer-' + v + suffix + '.test' for v in roots for suffix in ['-confirm', '-packed-confirm']]
bins += ['govpx-next-gather-pointer-bench', 'govpx-next-uv-zero-candidate-bench', 'govpx-asm-bench']
env['binary_sha256'] = {n: hashlib.sha256((base / n).read_bytes()).hexdigest() for n in bins}
env['source_sha256'] = {n: hashlib.sha256((base / 'govpx-next-gather-pointer' / n).read_bytes()).hexdigest() for n in names if (base / 'govpx-next-gather-pointer' / n).exists()}
(out / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
pairs = [a / b for x in component.values() for a, b in zip(x['samples']['parent'], x['samples']['candidate'])]
report = '''# Looped pointer-window VP8 residual gather

Native Apple M4 Max, Go1.27.2 archsimd, PGO off, one thread/GOMAXPROCS1.
Parent03afac7c (PR34), pinned assembly691cd051. This looped predecessor
is preserved independently of the subsequent fixed-row follow-up. Keep the existing paired-row
4x4 block-scan arithmetic; use exact pointer row loads and coefficient stores
in the existing public pointer API instead of rebuilding dynamic slices and
checking each SIMD window. Non-nil pointers and0<=strides<2^48 are checked before
unsafe access; max input offset is15*stride+15<2^52. Complete allocations and
nonoverlapping output remain existing PtrFast caller preconditions. Read-only
rows and source/predictor windows may overlap. Declines retain old fallback.

Two fresh six-permutation three-way studies,150ms B.Loop: original two public
fixtures, eight unaligned/minimal-row fixtures with unequal padded strides,
then eight with tightly packed predictors. All18 medians beat parent by1.5x.
Fixture source is identical across parent/ASM/current. New fixtures check every
coefficient against independent scalar math, both input buffers and all output
canaries after B.Loop; global sinks retain work. Every sample is zero B/op and
zero allocs/op. Initial two-round diagnostics are separately preserved.

'''
report += f"Median parent/current range {min(x['speedup'] for x in component.values()):.4f}–{max(x['speedup'] for x in component.values()):.4f}x. {sum(p >= 1.5 for p in pairs)}/{len(pairs)} individual pairs reach1.5x; minimum pair {min(pairs):.4f}x. Preserve all slower/outlier samples; do not claim every pair reaches1.5x.\n\n"
for width in [16, 8]:
    cases = [x for n, x in component.items() if f'/w{width}/' in n or n.endswith(f'/{width}x{width}')]
    report += f"{width}x{width}: {min(x['speedup_assembly'] for x in cases):.4f}–{max(x['speedup_assembly'] for x in cases):.4f}x assembly.\n\n"
report += 'Retain correctness-verified component gains under AGENTS.md independently of whole codec. Whole synthetic720p VP8,realtime CPU8,2500kbps,six fresh balanced permutations:\n'
for frames in ['300', '60']:
    x = public[frames]
    report += f"\n* {frames}frames: {x['vs_parent_percent']:+.3f}% encode time versus parent ({x['faster_parent_pairs']}/6 faster), {x['vs_assembly_percent']:+.3f}% versus ASM ({x['faster_assembly_pairs']}/6 faster).\n"
report += '''
All23 non-timing fields match, allocations remain zero. Kernel and encoder
figures stay separate; no closure of the overall ARM assembly gap is inferred.

Correctness: full native ./..., existing randomized/extreme residual oracles,
336 new public row/alignment/extreme cases, direct selected-path scalar checks
with mutually aliased inputs, exact stride-boundary/nil/disabled declines,
race/checkptr2. AMD selected and actualAVX/AVX2-off correctness runs use Rosetta,
never its timings. Initial test-only compile error attempted to mutate ARM's
constant Enabled flag; the runtime-disabled test now has AMD-only build tags.
Both failure and passing retry remain raw evidence.

Generated code: both sizes are leaf functions without panic/bounds calls on
ARM and AMD. ARM has82/94 instruction lines; AMD128/163, all counts nonzero.
Those are diagnostics, not x64 native speed evidence. New native CI fixtures
and required direct-path/public-row tests measure actual x64 next. No README
or dependency changes. An independent read-only review verifies bounds,
store coverage, lifetimes, fallback and benchmark contracts.
'''
(out / 'REPORT.md').write_text(report)
print(out, len(payload))
