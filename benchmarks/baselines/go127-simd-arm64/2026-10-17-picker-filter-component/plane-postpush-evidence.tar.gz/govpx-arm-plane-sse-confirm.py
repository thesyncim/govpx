import os,json,subprocess
from pathlib import Path
env=dict(os.environ,GOMAXPROCS='1',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='root-arm-plane-confirm')
names=['parent','candidate'];bins=['/private/tmp/govpx-complete-denoise-final-bench','/private/tmp/govpx-arm-plane-sse-bench'];rows=[]
for r in range(8):
 for i in ([0,1] if r%2==0 else [1,0]):
  args=['/Users/thesyncim/.codex/bin/project-env',bins[i],'-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
  rows.append(dict(round=r+1,variant=names[i],result=json.loads(subprocess.check_output(args,env=env,text=True))))
 Path('/private/tmp/govpx-arm-plane-sse-confirm.json').write_text(json.dumps({'samples':rows},indent=2)+'\n');print('ARM plane confirmation round',r+1,'done',flush=True)
