import os,subprocess,pathlib,json,re,statistics,hashlib
out=pathlib.Path('/private/tmp/govpx-next-quant-eob-measurements');out.mkdir(exist_ok=True)
bins={v:'/private/tmp/govpx-next-quant-eob-'+v+'.test' for v in ['parent','candidate']}
env=os.environ.copy();env['GOMAXPROCS']='1'
rows={v:{} for v in bins}
for r,order in enumerate([['parent','candidate'],['candidate','parent']]*3,1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkFastQuantizeBatchNative$','-test.benchtime=200ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout)
  if p.returncode: raise SystemExit(p.stdout)
  for name,ns,b,a in re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M):
   assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns))
summary={k:{'parent':rows['parent'][k],'candidate':c,'speedup':statistics.median(rows['parent'][k])/statistics.median(c),'faster_pairs':sum(a>b for a,b in zip(rows['parent'][k],c))} for k,c in rows['candidate'].items()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
