import json,statistics
from pathlib import Path
rows=json.load(open('/private/tmp/govpx-next-quant-eob-public.json'))['samples'];out={};ignored={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns'}
for f in [300,60]:
 r=[x for x in rows if x['frames']==f];ref=r[0]['result'];fields=set(ref)-ignored
 assert len(r)==18
 assert all({k:x['result'][k] for k in fields}=={k:ref[k] for k in fields} for x in r)
 d={v:[x['result']['ns_per_frame'] for x in r if x['variant']==v] for v in ['assembly','parent','candidate']};m={v:statistics.median(a) for v,a in d.items()}
 out[str(f)]={'samples':d,'median_ns':m,'vs_parent_percent':(m['candidate']/m['parent']-1)*100,'vs_assembly_percent':(m['candidate']/m['assembly']-1)*100,'faster_parent_pairs':sum(a>b for a,b in zip(d['parent'],d['candidate'])),'faster_assembly_pairs':sum(a>b for a,b in zip(d['assembly'],d['candidate'])),'exact_fields':sorted(fields),'allocations':ref['allocs_per_frame'],'limits':'Same shared desktop timing window; no isolated causal attribution for shifts larger than the component/profile expectation.'}
Path('/private/tmp/govpx-next-quant-eob-public-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
