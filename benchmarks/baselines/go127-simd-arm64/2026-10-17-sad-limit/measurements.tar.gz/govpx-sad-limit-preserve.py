import re,json,statistics,hashlib,tarfile
from pathlib import Path
root=Path('/Users/thesyncim/GolandProjects/govpx'); temp=Path('/private/tmp'); out=root/'benchmarks/baselines/go127-simd-arm64/2026-10-17-sad-limit';out.mkdir(exist_ok=True,parents=True)
# Capture exact accepted source plus tests independently of build artifacts.
selected=['internal/pixel/sad_limit16_arm64.go','internal/pixel/sad_limit16_arm64_test.go','internal/vp8/dsp/sad_dispatch_other.go','internal/vp8/dsp/sad_limit16_arm64.go','internal/vp8/dsp/sad_limit16_other.go','internal/vp8/dsp/sad_limit_native_test.go','scripts/benchmark-amd64.sh']
with tarfile.open(out/'sources.tar.gz','w:gz') as t:
 for name in selected:t.add(root/name,arcname=name)
 t.add(temp/'govpx-sad-limit-source-before-tuning.tar.gz',arcname='earlier-pointer-sources.tar.gz')
 t.add(temp/'govpx-sad-limit-source-before-dispatch-split.tar.gz',arcname='before-dispatch-split-sources.tar.gz')
 t.add(temp/'govpx-sad-limit-source-checked-pair-final.tar.gz',arcname='checked-pair-final-sources.tar.gz')
# Every raw sample is preserved, including aborted or contended trials.
raws=set()
for pattern in ['govpx-sad-limit-*.txt','govpx-sad-limit-*.json','govpx-sad-limit-*.log','govpx-sad-limit-*.py','govpx-arm-sad-limit-*.json','govpx-arm-sad-limit-*.py']:
 raws.update(temp.glob(pattern))
raws.update(p for p in (temp/'govpx-sad-limit-validation').iterdir() if p.is_file() and p.suffix in ('.log','.json','.txt','.diff'))
manifest={}
with tarfile.open(out/'measurements.tar.gz','w:gz') as t:
 for p in sorted(raws):
  if p.is_file():
   name=p.relative_to(temp).as_posix();t.add(p,arcname=name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'raw-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['govpx-sad-limit-final-summary.json','govpx-sad-limit-confirm-summary.json','govpx-sad-limit-final-environment.json','govpx-sad-limit-public-summary.json','govpx-sad-limit-selected-environment.json','govpx-sad-limit-selected-summary.json','govpx-sad-limit-selected-public-summary.json','govpx-sad-limit-selected-public60-summary.json']:
 p=temp/name
 if p.exists():(out/name.replace('govpx-sad-limit-','')).write_bytes(p.read_bytes())
print(out,len(manifest))
