import os,subprocess,json,time
from pathlib import Path
env=dict(os.environ,GOMAXPROCS='1',CODEX_AGENT_ID='root-sad-final-native')
names=['assembly','parent','candidate'];bins={n:'/private/tmp/govpx-sad-limit-final-'+n+'.test' for n in names};bins['candidate']='/private/tmp/govpx-sad-limit-selected-candidate.test';orders=[[0,1,2],[1,2,0],[2,0,1],[0,2,1],[2,1,0],[1,0,2]]
for n in names:Path('/private/tmp/govpx-sad-limit-selected-'+n+'.txt').write_text('')
for r,order in enumerate(orders):
 for i in order:
  with Path('/private/tmp/govpx-sad-limit-selected-'+names[i]+'.txt').open('a') as f:
   f.write('# round '+str(r+1)+' '+time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())+'\n');f.flush()
   subprocess.run([bins[names[i]],'-test.run=^$','-test.bench=^BenchmarkSADLimitNative$','-test.benchtime=150ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('ARM selected SAD round',r+1,'done',flush=True)
