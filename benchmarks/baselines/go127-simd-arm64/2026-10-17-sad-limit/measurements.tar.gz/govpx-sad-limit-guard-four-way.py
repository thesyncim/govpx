import os,subprocess
from pathlib import Path
env=dict(os.environ,GOMAXPROCS='1',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='root-sad-limit-native')
names=['assembly','parent','pointer','guard'];orders=[[0,1,2,3],[1,2,3,0],[2,3,0,1],[3,0,1,2],[3,2,1,0],[0,3,2,1],[1,0,3,2],[2,1,0,3]]
for n in names:Path('/private/tmp/govpx-sad-limit-guard-four-way-'+n+'.txt').write_text('')
for r,order in enumerate(orders):
 for i in order:
  with Path('/private/tmp/govpx-sad-limit-guard-four-way-'+names[i]+'.txt').open('a') as f:
   f.write('# round '+str(r+1)+'\n');f.flush()
   subprocess.run(['/Users/thesyncim/.codex/bin/project-env','/private/tmp/govpx-sad-limit-arm-'+names[i]+'.test','-test.run=^$','-test.bench=^BenchmarkSADLimitNative$','-test.benchtime=150ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('ARM SAD limit round',r+1,'done',flush=True)
