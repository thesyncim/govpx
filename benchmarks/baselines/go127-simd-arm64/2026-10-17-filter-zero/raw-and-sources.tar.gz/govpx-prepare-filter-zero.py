from pathlib import Path
import subprocess,tarfile,io
snapshot=subprocess.check_output(['git','archive','20bc81cbbf68985f4619b6d69f3f3d60566ba013'])
for variant in ['parent','candidate']:
 root=Path('/private/tmp/govpx-next-filter-zero-'+variant);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(snapshot)) as t:t.extractall(root)
 fixture=root/'internal/vp8/decoder/picker_filter_native_bench_test.go'
 s=fixture.read_text().replace('[]string{"smooth", "mixed", "noop"}','[]string{"flat", "smooth", "mixed", "noop"}')
 s=s.replace('v := byte(112 + (x*3+y*5)%17)','v := byte(112 + (x*3+y*5)%17)\n if pattern=="flat" {v=128}')
 fixture.write_text(s)
 if variant=='parent':continue
 f=root/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=f.read_text()
 needle='\t\t\tf := lfFilterDelta(outerF, p0c, q0c).Masked(need)'
 positions=[];start=0
 while True:
  at=s.find(needle,start)
  if at<0:break
  # f is directly inside the nonempty-need branch. Find that branch's end.
  rest=at+len(needle);depth=1;i=rest
  while depth:
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  positions.append((rest,i-1));start=i
 assert len(positions)==4,len(positions)
 for a,b in reversed(positions):
  s=s[:b]+'}\n\t\t'+s[b:]
  s=s[:a]+'\n\t\t\tif f.ToBits().ReduceMax() != 0 {'+s[a:]
 f.write_text(s)
 print(root)
