import json,statistics
from pathlib import Path
prefix=Path('/private/tmp/govpx-next-subtract-final-public');rows=json.loads(prefix.with_suffix('.json').read_text())['samples'];assert len(rows)==54
out={};ignore={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
for case in ['vp9-320p','vp9-720p','vp8-720p-control']:
 r=[x for x in rows if x['case']==case];assert len(r)==18
 ref={k:v for k,v in r[0]['result'].items() if k not in ignore};assert len(ref)==22
 assert all({k:v for k,v in x['result'].items() if k not in ignore}==ref for x in r),case
 samples={v:[x['result']['ns_per_frame'] for x in sorted(r,key=lambda x:x['round']) if x['variant']==v] for v in ['assembly','parent','candidate']};med={v:statistics.median(a) for v,a in samples.items()}
 alloc={v:[x['result']['allocs_per_frame'] for x in sorted(r,key=lambda x:x['round']) if x['variant']==v] for v in samples}
 out[case]={'samples':samples,'median_ns':med,'vs_parent_percent':(med['candidate']/med['parent']-1)*100,'vs_assembly_percent':(med['candidate']/med['assembly']-1)*100,'faster_parent_pairs':sum(a<b for a,b in zip(samples['candidate'],samples['parent'])),'faster_assembly_pairs':sum(a<b for a,b in zip(samples['candidate'],samples['assembly'])),'exact_semantic_fields':sorted(ref),'allocation_samples':alloc,'all_allocation_samples_match':len({v for a in alloc.values() for v in a})==1,'scope':'Native serial M4 Max, PGO off, GOMAXPROCS1; whole codec separate from kernel. Shared desktop does not isolate small shifts or cross-run causal effects.'}
Path(str(prefix)+'-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for case,v in out.items():print(case,v['vs_parent_percent'],v['faster_parent_pairs'],v['vs_assembly_percent'],'allocs',v['allocation_samples'])
