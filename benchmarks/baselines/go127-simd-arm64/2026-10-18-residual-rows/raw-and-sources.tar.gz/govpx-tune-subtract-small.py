from pathlib import Path
import shutil
base=Path('/private/tmp/govpx-next-subtract16-pointers-candidate');root=Path('/private/tmp/govpx-next-subtract16-small-candidate');shutil.copytree(base,root,dirs_exist_ok=True)
p=root/'internal/pixel/kernels_simd.go';s=p.read_text();old='w >= 16 && w <= 64 && w%16 == 0';assert s.count(old)==1;s=s.replace(old,'(w == 4 || w == 8 || (w >= 16 && w <= 64 && w%16 == 0))');p.write_text(s)
p=root/'internal/pixel/subtract16_simd.go';s=p.read_text();old='return subtract16Rows(sp, ss, pp, ps, op, os, w, h), true';assert old in s;s=s.replace(old,'''if w==4 {return subtractSmallRows4(sp,ss,pp,ps,op,os,h),true}
 if w==8 {return subtractSmallRows8(sp,ss,pp,ps,op,os,h),true}
 '''+old);s=s.replace('import "unsafe"','import("unsafe";"simd/archsimd")')
for w,ctype,vtype in [(4,'uint32','Uint32x4'),(8,'uint64','Uint64x2')]:
 store='*(*uint64)(op)=d.ToBits().ReshapeToUint64s().GetElem(0)' if w==4 else 'd.StoreArray((*[8]int16)(op))'
 s+=f'''
func subtractSmallRows{w}(sp unsafe.Pointer,ss int,pp unsafe.Pointer,ps int,op unsafe.Pointer,os,h int)bool{{
 var bits archsimd.Int16x8
 for {{
  a:=(archsimd.{vtype}{{}}).SetElem(0,*(*{ctype})(sp)).ReshapeToUint8s()
  b:=(archsimd.{vtype}{{}}).SetElem(0,*(*{ctype})(pp)).ReshapeToUint8s()
  d:=widen8(a).Sub(widen8(b));{store};bits=bits.Or(d)
  h--;if h==0{{break}}
  sp=unsafe.Add(sp,ss);pp=unsafe.Add(pp,ps);op=unsafe.Add(op,2*os)
 }}
 q:=bits.ToBits().ReshapeToUint64s();return q.GetElem(0)|q.GetElem(1)!=0
}}
'''
p.write_text(s)
p=root/'internal/pixel/subtract16_simd_test.go';s=p.read_text().replace('[]int{16, 32, 48, 64}','[]int{4, 8, 16, 32, 48, 64}');p.write_text(s)
print(root)
