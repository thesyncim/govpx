from pathlib import Path
import subprocess,tarfile,io
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();root=Path.cwd()
for v in ['parent','candidate']:
 d=Path('/private/tmp/govpx-next-subtract16-'+v);d.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head]))) as t:t.extractall(d,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
d=Path('/private/tmp/govpx-next-subtract16-candidate');p=d/'internal/pixel/kernels_simd.go';s=p.read_text();marker='''\tif !Enabled {
		return SubtractScalar(src, ss, pred, ps, out, os, w, h)
	}
''';assert s.count(marker)==1
s=s.replace(marker,marker+'''
 if w>=16 && w<=64 && w%16==0 && h>0 && h<=64 && (uint(ss)|uint(ps)|uint(os))>>30==0 {
  if nz,ok:=subtract16Bounded(src,ss,pred,ps,out,os,w,h);ok{return nz}
 }
''');p.write_text(s)
(d/'internal/pixel/subtract16_simd.go').write_text('''//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import "unsafe"

// The caller bounds dimensions and strides. Decline incomplete windows so
// the checked fallback preserves its original partial-write/panic behavior.
func subtract16Bounded(src []byte, ss int, pred []byte, ps int, out []int16, os,w,h int)(bool,bool){
 sn,pn,on:=(h-1)*ss+w,(h-1)*ps+w,(h-1)*os+w
 if sn>len(src)||pn>len(pred)||on>len(out){return false,false}
 sp,pp,op:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(pred)),unsafe.Pointer(unsafe.SliceData(out))
 // Wider reads must not observe output stores earlier than the eight-lane
 // fallback. Read-only input aliases are fine; output/input overlap declines.
 su,pu,ou:=uintptr(sp),uintptr(pp),uintptr(op)
 if ou-su<uintptr(sn)||su-ou<uintptr(2*on)||ou-pu<uintptr(pn)||pu-ou<uintptr(2*on){return false,false}
 return subtract16Rows(sp,ss,pp,ps,op,os,w,h),true
}
''')
(d/'internal/pixel/subtract16_arm64.go').write_text('''//go:build goexperiment.simd && arm64 && !purego
package pixel
import("simd/archsimd";"unsafe")
// Sixteen-column residual layout adapted from goav1 residualBlockSIMD,
// rdstats_gosimd.go at0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a.
func subtract16Rows(sp unsafe.Pointer,ss int,pp unsafe.Pointer,ps int,op unsafe.Pointer,os,w,h int)bool{
 var bits archsimd.Int16x8
 so,po,oo:=0,0,0
 for range h{
  for x:=0;x<w;x+=16{
   a:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,so+x)))
   b:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(pp,po+x)))
   lo:=widen8(a).Sub(widen8(b));hi:=widenHi8(a).BitsToInt16().Sub(widenHi8(b).BitsToInt16())
   lo.StoreArray((*[8]int16)(unsafe.Add(op,2*(oo+x))))
   hi.StoreArray((*[8]int16)(unsafe.Add(op,2*(oo+x+8))))
   bits=bits.Or(lo).Or(hi)
  }
  so+=ss;po+=ps;oo+=os
 }
 q:=bits.ToBits().ReshapeToUint64s();return q.GetElem(0)|q.GetElem(1)!=0
}
''')
(d/'internal/pixel/subtract16_amd64.go').write_text('''//go:build goexperiment.simd && amd64 && !purego
package pixel
import("simd/archsimd";"unsafe")
func subtract16Rows(sp unsafe.Pointer,ss int,pp unsafe.Pointer,ps int,op unsafe.Pointer,os,w,h int)bool{
 defer archsimd.ClearAVXUpperBits()
 var bits archsimd.Int16x16
 so,po,oo:=0,0,0
 for range h{
  for x:=0;x<w;x+=16{
   a:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,so+x)))
   b:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(pp,po+x)))
   d:=a.ExtendToUint16().BitsToInt16().Sub(b.ExtendToUint16().BitsToInt16())
   d.StoreArray((*[16]int16)(unsafe.Add(op,2*(oo+x))));bits=bits.Or(d)
  }
  so+=ss;po+=ps;oo+=os
 }
 q:=bits.GetLo().Or(bits.GetHi()).ToBits().ReshapeToUint64s();return q.GetElem(0)|q.GetElem(1)!=0
}
''')
Path('/private/tmp/govpx-next-subtract16-base.txt').write_text(head+'\n');print(head)
