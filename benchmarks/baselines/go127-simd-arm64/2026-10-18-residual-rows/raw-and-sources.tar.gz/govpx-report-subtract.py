from pathlib import Path
import json
base=Path('/private/tmp');out=base/'govpx-subtract-ready';out.mkdir(exist_ok=True)
data=json.loads((base/'govpx-next-subtract-final-confirm/summary.json').read_text());whole=json.loads((base/'govpx-next-subtract-final-public-summary.json').read_text())
s='''# Bounded SIMD residual subtraction

Native Apple M4 Max, Go 1.27.2 darwin/arm64 archsimd, PGO off, GOMAXPROCS=1.
Immediate parent6a7b1444765e30fcbcc4a5aca8abd1af73dd9013 includes the repaired
AMD vertical carrier from PR #37 and the SSE winner from PR #38. Old assembly
reference691cd0512c4829d9ee40d483205dd223f9eb028d. No cross-CPU attribution.

Adapt the sixteen-column residual layout from goav1 residualBlockSIMD at
0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a, with no module dependency. ARM loads
16 pixels and stores two eight-coefficient packets. AMD widens to AVX2, stores
16 coefficients and defers upper-state cleanup. Dedicated four/eight-pixel
kernels read exactly4/8 bytes, compute signed int16 residuals and store exactly
4/8 coefficients. Four-pixel unused SIMD lanes remain zero. Fused OR over all
computed residuals preserves nonzero even if later output rows overlap earlier.

The dispatcher proves widths4/8 or16-multiples through64, h1..64 and nonnegative
strides<2^30. Complete visible input/output lengths are checked before unsafe
access. Their row offsets fit below2^36, output byte offsets below2^37. Typed
row pointers advance only when another row remains, never forming an unused
out-of-object final pointer. Zero/overlapping strides and read-only input
aliases remain valid; output/input overlap conservatively declines BEFORE
stores, preserving the original eight-lane/scalar partial-write ordering.
Short windows decline to the original checked fallback, preserving its panic
and whole-buffer post-panic state. Larger/unsupported geometry and CPU-off keep
the parent behavior. No handwritten assembly, production cgo or new dependency.

Fresh six balanced parent/assembly/current orders,100ms per48 identical public
B.Loop fixtures: eight shapes, two stride/output layouts and random/max-error/
identical patterns. Origins3/5 and coefficient origin1, exact visible windows,
independent per-coefficient and boolean oracles before/after timing, complete
input and output backing canaries, and observable outputs. Every kernel sample
has zero B/op and allocations. Ranges cover the three pixel patterns.

| Shape / padded output | Parent/current time | Old-reference/current public time | Minimum paired parent/current |
|---|---:|---:|---:|
'''
for size in ['4x4','8x8','16x8','16x16','32x16','32x32','64x32','64x64']:
 for pad in ['false','true']:
  rows=[v for n,v in data.items() if '/'+size+'/padded'+pad+'/' in n]
  assert len(rows)==3
  s+=f"| {size} / {pad} | {min(v['speedup'] for v in rows):.4f}–{max(v['speedup'] for v in rows):.4f}x | {min(v['speedup_assembly'] for v in rows):.4f}–{max(v['speedup_assembly'] for v in rows):.4f}x | {min(v['minimum_paired_speedup'] for v in rows):.4f}x |\n"
s+=f'''
All48 cases qualify at{min(v['speedup'] for v in data.values()):.4f}–{max(v['speedup'] for v in data.values()):.4f}x parent;
all288 paired samples are at least{min(v['minimum_paired_speedup'] for v in data.values()):.4f}x. Preserve these verified
component wins independently of overall codec timing. Contiguous32/64-column
cases beat the old NEON path, while smaller contiguous cases still trail it.
The old reference rejects outStride!=w and uses SCALAR for every padded-output
fixture; its larger padded ratios are public fallback wins, not claims of
beating active assembly instructions by that factor.

Whole codec, synthetic input, realtime CPU8,one thread, PGO off, six balanced
rounds (positive means more time/slower):
'''
for case,v in whole.items():s+=f"\n* {case}: {v['vs_parent_percent']:+.4f}% versus parent ({v['faster_parent_pairs']}/6 faster), {v['vs_assembly_percent']:+.4f}% versus old assembly ({v['faster_assembly_pairs']}/6 faster).\n"
s+='''
VP9 workloads are320x180/120frames/500kbps and1280x720/60frames/2500kbps;
VP8 control is1280x720/60frames/2500kbps. All22 semantic fields match across
all variants and every allocation sample matches: existing VP9 allocations
are0.6166667 and1.25 per input respectively; VP8 allocates zero. Matching output
statistics do not assert bitstream identity. The whole ARM assembly gaps remain
open. Subtract has no VP8 production caller, so its mixed-pair +0.4937% VP8 result
is retained as a control, with no claimed benefit or causal attribution. These
Go-assembly comparisons do not establish equivalent libvpx C performance; C
has separate native CI jobs and output/quality scope.

Correctness: full native suite, ARM race/checkptr2, combined AMD residual/
subpixel/SSE checkptr under Rosetta, and actual AVX-off fallback pass. New tests
run5,760 geometry/pattern/alias iterations (5,040 also call the selected bounded
helper), with os0/1/w-1/contiguous/padded, h65 fallback, minimum windows and
mutual read-only aliases. Sixty-six output/input overlap geometries compare
complete backing state to the copied parent kernel, and45 short-window
geometries compare recovered-panic backing state. Both src/pred aliases and
exact adjacency are covered. Independent source/arithmetic/bounds/CI review
passes. Root files exactly match the final measured private candidate.

Saved optimized Darwin/amd64 code has VEX-only wide inner-loop arithmetic and
normal-return upper-state cleanup. Legacy prologue initialization occurs before
AVX use; no whole-function all-VEX claim. Generated code and Rosetta are not
native x64 speed evidence. Corrected AMD subpixel source remains unchanged at
SHA2565b21747a9df17eb8957dc2424b64dacf2da9986621a90bc779428ea414638aa4.
Native x64 performance is pending this successor's exact-head CI.

PGO refreshed, fingerprint/noasm/SIMD-selection/pre-commit gates pass. Native
harness retains282 previous controls and adds48 fixtures for330 total, copying
the same fixture to both references, recording14 source hashes and requiring
all three new tests in normal/race preflight. Benchmark timeout grows35→45min
to accommodate the larger suite; no correctness threshold is relaxed. README
files remain untouched.

All raw samples, diagnostics, source variants and drivers are retained. The
initial wide-only source qualified at1.9–3.0x but regressed the unchanged4x4
control; moving row pointers removed integer/address pressure, then dedicated
small-width SIMD removed that regression. Final fresh runs confirm all48 gains
independently. No competing local Go builds/tests/profiles ran during timing.
Shared-desktop results do not isolate small control shifts or support adding
gains from different checkpoints/CPUs.
'''
for a,b in [('parent6a','parent 6a'),('reference691','reference 691'),('exactly4/8','exactly 4/8'),('widths4/8','widths 4/8'),('or16-multiples','or 16-multiples'),('through64','through 64'),('h1..64','h=1..64'),('below2^','below 2^'),('orders,100ms per48','orders, 100ms per 48'),('Origins3/5','Origins 3/5'),('origin1','origin 1'),('All48','All 48'),('qualify at','qualify at '),('all288','all 288'),('least1.','least 1.'),('Contiguous32/64','Contiguous 32/64'),('CPU8,one','CPU 8, one'),('are320x180/120frames/500kbps and1280x720/60frames/2500kbps','are 320x180 / 120 frames / 500 kbps and 1280x720 / 60 frames / 2500 kbps'),('is1280x720/60frames/2500kbps','is 1280x720 / 60 frames / 2500 kbps'),('All22','All 22'),('are0.6166667 and1.25','are 0.6166667 and 1.25'),('run5,760','run 5,760'),('and45','and 45'),('SHA2565b','SHA256 5b'),('retains282','retains 282'),('adds48','adds 48'),('for330','for 330'),('recording14','recording 14'),('grows35→45min','grows 35→45 min'),('at1.9','at 1.9'),('unchanged4x4','unchanged 4x4'),('all48','all 48')]:s=s.replace(a,b)
(out/'REPORT.md').write_text(s);print('report ready')
