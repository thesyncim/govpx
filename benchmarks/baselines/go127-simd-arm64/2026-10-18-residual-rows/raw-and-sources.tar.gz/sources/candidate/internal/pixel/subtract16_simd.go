//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import "unsafe"

// The caller bounds dimensions and strides. Decline incomplete windows so
// the checked fallback preserves its original partial-write/panic behavior.
func subtract16Bounded(src []byte, ss int, pred []byte, ps int, out []int16, os, w, h int) (bool, bool) {
	sn, pn, on := (h-1)*ss+w, (h-1)*ps+w, (h-1)*os+w
	if sn > len(src) || pn > len(pred) || on > len(out) {
		return false, false
	}
	sp, pp, op := unsafe.Pointer(unsafe.SliceData(src)), unsafe.Pointer(unsafe.SliceData(pred)), unsafe.Pointer(unsafe.SliceData(out))
	// Wider reads must not observe output stores earlier than the eight-lane
	// fallback. Read-only input aliases are fine; output/input overlap declines.
	su, pu, ou := uintptr(sp), uintptr(pp), uintptr(op)
	if ou-su < uintptr(sn) || su-ou < uintptr(2*on) || ou-pu < uintptr(pn) || pu-ou < uintptr(2*on) {
		return false, false
	}
	return subtract16Rows(sp, ss, pp, ps, op, os, w, h), true
}
