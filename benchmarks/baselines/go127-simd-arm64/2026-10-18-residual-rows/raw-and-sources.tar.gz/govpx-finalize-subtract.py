from pathlib import Path
import shutil,subprocess,tarfile,io
base=Path('/private/tmp');repo=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();source=base/'govpx-next-subtract16-small-candidate'
for v in ['parent','candidate']:
 d=base/('govpx-next-subtract-final-'+v);d.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head]))) as t:t.extractall(d,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
d=base/'govpx-next-subtract-final-candidate'
for old,new in [('internal/pixel/kernels_simd.go','internal/pixel/kernels_simd.go'),('internal/pixel/subtract16_simd.go','internal/pixel/subtract_rows_simd.go'),('internal/pixel/subtract16_arm64.go','internal/pixel/subtract_rows_arm64.go'),('internal/pixel/subtract16_amd64.go','internal/pixel/subtract_rows_amd64.go'),('internal/pixel/subtract16_simd_test.go','internal/pixel/subtract_rows_simd_test.go')]:
 s=(source/old).read_text().replace('subtract16Bounded','subtractRowsBounded').replace('subtract16Selected','subtractRowsSelected').replace('subtract16Legacy','subtractRowsLegacy').replace('TestSubtract16Rows','TestSubtractRows').replace('at0f40','at 0f40')
 s=s.replace('// Aligned output at byte128; source starts at128+delta. Input16x2\n\t\t\t\t\t// spans32bytes, output spans64bytes. Test both src and pred overlap.','// Aligned output starts at byte128; input starts at128+delta.\n\t\t\t\t\t// Their spans are2*w and4*w bytes. Test both input aliases.')
 (d/new).write_text(s)
fixture=(source/'internal/vp9/dsp/subtract16_native_test.go').read_text().replace('BenchmarkSubtract16Native','BenchmarkSubtractRowsNative').replace('subtract16NativeSink','subtractRowsNativeSink')
for v in ['parent','candidate']:(base/('govpx-next-subtract-final-'+v)/'internal/vp9/dsp/subtract_rows_native_test.go').write_text(fixture)
a=base/'govpx-next-subtract16-assembly';shutil.copytree(a,base/'govpx-next-subtract-final-assembly',dirs_exist_ok=True);a=base/'govpx-next-subtract-final-assembly';(a/'internal/vp9/dsp/subtract16_native_test.go').unlink();(a/'internal/vp9/dsp/subtract_rows_native_test.go').write_text(fixture)
for n in ['vp8/vp8_cx_iface.c','vp8/vp8_dx_iface.c']:
 p=Path('internal/coracle/build/libvpx-v1.16.0-vpxenc-purec')/n;(d/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,d/p)
(base/'govpx-next-subtract-final-base.txt').write_text(head+'\n');print(head)
