from pathlib import Path
import shutil
src=Path('/private/tmp/govpx-next-subtract16-candidate');dst=Path('/private/tmp/govpx-next-subtract16-pointers-candidate');shutil.copytree(src,dst,dirs_exist_ok=True)
for arch in ['arm64','amd64']:
 p=dst/('internal/pixel/subtract16_'+arch+'.go');s=p.read_text();assert 'so, po, oo := 0, 0, 0' in s
 s=s.replace('so, po, oo := 0, 0, 0\n\tfor range h {','for {')
 s=s.replace('unsafe.Add(sp, so+x)','unsafe.Add(sp, x)').replace('unsafe.Add(pp, po+x)','unsafe.Add(pp, x)').replace('2*(oo+x+8)','2*(x+8)').replace('2*(oo+x)','2*x')
 old='''\t\tso += ss
		po += ps
		oo += os''';assert old in s
 s=s.replace(old,'''\t\th--
		if h == 0 { break }
		// Advance only when another row remains; each pointer stays within
		// its validated object even with an unused large final stride.
		sp=unsafe.Add(sp,ss)
		pp=unsafe.Add(pp,ps)
		op=unsafe.Add(op,2*os)''');p.write_text(s)
print(dst)
