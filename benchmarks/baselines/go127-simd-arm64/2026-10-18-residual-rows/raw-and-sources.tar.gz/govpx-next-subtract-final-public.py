import os,json,subprocess
from pathlib import Path
env=dict(os.environ,GOMAXPROCS='1');names=['assembly','parent','candidate'];bins=['/private/tmp/govpx-asm-bench','/private/tmp/govpx-next-subtract-final-parent-bench','/private/tmp/govpx-next-subtract-final-candidate-bench'];orders=[[0,1,2],[1,2,0],[2,0,1],[0,2,1],[2,1,0],[1,0,2]];rows=[]
for name,codec,width,height,frames,bitrate in [('vp9-320p','vp9',320,180,120,500),('vp9-720p','vp9',1280,720,60,2500),('vp8-720p-control','vp8',1280,720,60,2500)]:
 for r,order in enumerate(orders,1):
  for i in order:
   args=[bins[i],'-codec='+codec,'-width='+str(width),'-height='+str(height),'-frames='+str(frames),'-fps=30','-bitrate='+str(bitrate),'-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
   rows.append(dict(case=name,round=r,variant=names[i],result=json.loads(subprocess.check_output(args,env=env,text=True))))
  Path('/private/tmp/govpx-next-subtract-final-public.json').write_text(json.dumps({'samples':rows},indent=2)+'\n');print('public',name,'round',r,'done',flush=True)
