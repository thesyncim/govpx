from pathlib import Path
import hashlib,io,json,tarfile,subprocess
base=Path('/private/tmp');repo=Path('/Users/thesyncim/GolandProjects/govpx');out=base/'govpx-subtract-ready';out.mkdir(exist_ok=True);payload={}
for prefix in ['govpx-next-subtract16*','govpx-next-subtract-final*','govpx-next-subtract-root*']:
 for p in base.glob(prefix):
  if p.is_file() and p.suffix in ['.py','.log','.txt','.json','.go']:payload[p.name]=p.read_bytes()
  if p.is_dir() and (p/'summary.json').exists():
   for q in p.iterdir():
    if q.is_file() and q.suffix in ['.json','.txt']:payload[p.name+'/'+q.name]=q.read_bytes()
oldnames=['internal/pixel/kernels_simd.go','internal/pixel/subtract16_simd.go','internal/pixel/subtract16_arm64.go','internal/pixel/subtract16_amd64.go','internal/pixel/subtract16_simd_test.go','internal/vp9/dsp/subtract16_native_test.go']
newnames=['internal/pixel/kernels_simd.go','internal/pixel/subtract_rows_simd.go','internal/pixel/subtract_rows_arm64.go','internal/pixel/subtract_rows_amd64.go','internal/pixel/subtract_rows_simd_test.go','internal/vp9/dsp/subtract_rows_native_test.go']
for variant in ['parent','candidate','pointers-candidate','small-candidate']:
 for n in oldnames:
  p=base/('govpx-next-subtract16-'+variant)/n
  if p.exists():payload['sources/'+variant+'/'+n]=p.read_bytes()
for variant in ['parent','candidate']:
 for n in newnames:
  p=base/('govpx-next-subtract-final-'+variant)/n
  if p.exists():payload['sources/final-'+variant+'/'+n]=p.read_bytes()
for n in newnames+['scripts/benchmark-amd64.sh','.github/workflows/simd-amd64-bench.yml']:
 payload['final-production/'+n]=(repo/n).read_bytes()
for n in ['govpx-prepare-subtract16.py','govpx-tune-subtract16-pointers.py','govpx-tune-subtract-small.py','govpx-finalize-subtract.py','govpx-subtract16-native_test.go','govpx-subtract16-tests.go.txt','govpx-archive-subtract.py','govpx-report-subtract.py']:
 payload[n]=(base/n).read_bytes()
payload['goav1-reference/rdstats_gosimd.go']=subprocess.check_output(['git','-C','/Users/thesyncim/GolandProjects/goav1','show','0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a:internal/av1/encoder/rdstats_gosimd.go'])
data=json.loads((base/'govpx-next-subtract-final-confirm/summary.json').read_text());whole=json.loads((base/'govpx-next-subtract-final-public-summary.json').read_text());assert len(data)==48
assert all(v['speedup']>=1.5 and v['minimum_paired_speedup']>=1.5 and v['faster_parent_pairs']==6 for v in data.values())
assert all(len(v['samples'][kind])==6 for v in data.values() for kind in ['parent','candidate','assembly'])
for n in newnames:assert (repo/n).read_bytes()==(base/'govpx-next-subtract-final-candidate'/n).read_bytes(),n
with tarfile.open(out/'raw-and-sources.tar.gz','w:gz') as t:
 for n,b in sorted(payload.items()):
  f=tarfile.TarInfo(n);f.size=len(b);f.mtime=0;t.addfile(f,io.BytesIO(b))
(out/'raw-sha256.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())},indent=2)+'\n')
for n,v in [('component-summary',data),('public-summary',whole)]: (out/(n+'.json')).write_text(json.dumps(v,indent=2)+'\n')
env=json.loads((base/'govpx-next-subtract-final-environment.json').read_text());env['raw_members']=len(payload);(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n');print(out,len(payload))
