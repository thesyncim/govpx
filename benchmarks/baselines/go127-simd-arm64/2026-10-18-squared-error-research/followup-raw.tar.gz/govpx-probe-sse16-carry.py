from pathlib import Path
import shutil
p=Path('/private/tmp/govpx-sse16-arithmetic-carry');shutil.copytree('/private/tmp/govpx-sse16-arithmetic-parent',p,dirs_exist_ok=True)
f=p/'internal/pixel/sse16_simd_arm64.go';s=f.read_text().replace('import "simd/archsimd"','import ("simd/archsimd";"unsafe")')
code='''
 if uint(h-1)<4096 && (uint(ss)|uint(rs))>>30==0 {
 _=src[(h-1)*ss+15];_=ref[(h-1)*rs+15]
 sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
 var l,hv,lc,hc archsimd.Uint16x8
 for y:=0;y<h;y++ {
 a,b:=load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs))
 d:=a.Max(b).Sub(a.Min(b));dh:=highBytes(d)
 nl,nh:=l.Add(d.MulWidenLo(d)),hv.Add(dh.MulWidenLo(dh))
 lc=lc.Sub(l.Greater(nl).ToInt16x8().ToBits());hc=hc.Sub(hv.Greater(nh).ToInt16x8().ToBits())
 l,hv=nl,nh
 }
 ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32()).Add(hv.ExtendLo4ToUint32()).Add(hv.HiToLo().ExtendLo4ToUint32())
 cs:=lc.ExtendLo4ToUint32().Add(lc.HiToLo().ExtendLo4ToUint32()).Add(hc.ExtendLo4ToUint32()).Add(hc.HiToLo().ExtendLo4ToUint32())
 return uint32(sum32(ls.BitsToInt32()))+(uint32(sum32(cs.BitsToInt32()))<<16)
 }
'''
s=s.replace('\tvar lo, hi archsimd.Int32x4\n',code+'\n\tvar lo, hi archsimd.Int32x4\n',1);f.write_text(s);print('ready')
