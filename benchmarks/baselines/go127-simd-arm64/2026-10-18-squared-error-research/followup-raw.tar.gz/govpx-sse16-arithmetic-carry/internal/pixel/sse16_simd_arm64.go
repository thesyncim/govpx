//go:build goexperiment.simd && arm64 && !purego

package pixel

import ("simd/archsimd";"unsafe")

// SSE16 computes squared error over sixteen columns, without the signed
// sum needed by variance. Only the requested rows and columns are read;
// accumulation wraps modulo2^32, as in Stats.
func SSE16(src []byte, ss int, ref []byte, rs, h int) uint32 {
	if !Enabled {
		return SSE16Scalar(src, ss, ref, rs, h)
	}

 if uint(h-1)<4096 && (uint(ss)|uint(rs))>>30==0 {
 _=src[(h-1)*ss+15];_=ref[(h-1)*rs+15]
 sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
 var l,hv,lc,hc archsimd.Uint16x8
 for y:=0;y<h;y++ {
 a,b:=load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs))
 d:=a.Max(b).Sub(a.Min(b));dh:=highBytes(d)
 nl,nh:=l.Add(d.MulWidenLo(d)),hv.Add(dh.MulWidenLo(dh))
 lc=lc.Sub(l.Greater(nl).ToInt16x8().ToBits());hc=hc.Sub(hv.Greater(nh).ToInt16x8().ToBits())
 l,hv=nl,nh
 }
 ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32()).Add(hv.ExtendLo4ToUint32()).Add(hv.HiToLo().ExtendLo4ToUint32())
 cs:=lc.ExtendLo4ToUint32().Add(lc.HiToLo().ExtendLo4ToUint32()).Add(hc.ExtendLo4ToUint32()).Add(hc.HiToLo().ExtendLo4ToUint32())
 return uint32(sum32(ls.BitsToInt32()))+(uint32(sum32(cs.BitsToInt32()))<<16)
 }

	var lo, hi archsimd.Int32x4
	for y := range h {
		lo, hi = ssePacket(lo, hi, archsimd.LoadUint8x16(src[y*ss:]), archsimd.LoadUint8x16(ref[y*rs:]))
	}
	return uint32(sum32(lo.Add(hi)))
}
