from pathlib import Path
import subprocess,os,re,json,statistics
prefix='/private/tmp/govpx-sse16-arithmetic-';vs=['parent','carry'];out=Path(prefix+'carry-measurements');out.mkdir(exist_ok=True);env=dict(os.environ,GOMAXPROCS='1');rows={v:{} for v in vs}
for rnd,order in enumerate([vs,vs[::-1],vs,vs[::-1]],1):
 for v in order:
  p=subprocess.run([prefix+v+'.test','-test.run=^$','-test.bench=^BenchmarkSSE16WindowNative$','-test.benchtime=100ms','-test.cpu=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{rnd}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  found=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(found)==16
  for name,ns,b,a in found:assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns))
 print('round',rnd,'done',flush=True)
s={k:{'samples':{v:rows[v][k] for v in vs},'speedup':statistics.median(rows['parent'][k])/statistics.median(rows['carry'][k])} for k in rows['parent']};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
