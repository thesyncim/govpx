from pathlib import Path
import subprocess,io,tarfile,shutil
root=Path('/Users/thesyncim/GolandProjects/govpx');prefix='/private/tmp/govpx-sse16-arithmetic-'
raw=subprocess.check_output(['git','archive','HEAD',':(exclude)benchmarks/baselines'],cwd=root)
base=(root/'internal/pixel/sse16_simd_arm64.go').read_text()
start=base.index('\tvar lo, hi');end=base.index('\n\tfor y := range h',start)
for v in ['parent','abs','u8square','abs-unroll']:
 p=Path(prefix+v);p.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(p)
 shutil.copy2('/private/tmp/govpx-next-sse16-parent/internal/vp8/dsp/sse16_window_native_test.go',p/'internal/vp8/dsp/sse16_window_native_test.go')
 if v=='parent':continue
 src=base.replace('import "simd/archsimd"','import ("simd/archsimd";"unsafe")')
 packet='''d := a.Max(b).Sub(a.Min(b))
 dl,dh := widen8(d),widen8(highBytes(d))
 return lo.Add(square8(dl)),hi.Add(square8(dh))'''
 if v=='u8square':packet='''d:=a.Max(b).Sub(a.Min(b))
 l:=d.MulWidenLo(d);dh:=highBytes(d);h:=dh.MulWidenLo(dh)
 ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32())
 hs:=h.ExtendLo4ToUint32().Add(h.HiToLo().ExtendLo4ToUint32())
 return lo.Add(ls.BitsToInt32()),hi.Add(hs.BitsToInt32())'''
 body='''
 if uint(h-1)<4096 && (uint(ss)|uint(rs))>>30==0 {
 _=src[(h-1)*ss+15];_=ref[(h-1)*rs+15]
 sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
 for y:=0;y<h;y++ {lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))}
 return uint32(sum32(lo.Add(hi)))
 }
'''
 if v=='abs-unroll':body=body.replace('for y:=0;y<h;y++ {lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))}','''var l1,h1 archsimd.Int32x4;y:=0
 for ;y+2<=h;y+=2 {
 lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))
 l1,h1=probeSSEPacket(l1,h1,load16(unsafe.Add(sp,(y+1)*ss)),load16(unsafe.Add(rp,(y+1)*rs)))
 }
 if y<h {lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))}
 lo=lo.Add(l1);hi=hi.Add(h1)''')
 src=src.replace('\tvar lo, hi archsimd.Int32x4\n','\tvar lo, hi archsimd.Int32x4\n'+body,1)
 src+='\nfunc probeSSEPacket(lo,hi archsimd.Int32x4,a,b archsimd.Uint8x16)(archsimd.Int32x4,archsimd.Int32x4){'+packet+'}\n'
 (p/'internal/pixel/sse16_simd_arm64.go').write_text(src)
print(prefix)
