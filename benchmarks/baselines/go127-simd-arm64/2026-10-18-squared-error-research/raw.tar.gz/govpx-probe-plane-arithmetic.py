from pathlib import Path
import subprocess,tarfile,io,shutil
root=Path('/Users/thesyncim/GolandProjects/govpx');raw=subprocess.check_output(['git','archive','HEAD',':(exclude)benchmarks/baselines'],cwd=root)
for v in ['pointer','u8square']:
 p=Path('/private/tmp/govpx-plane-arithmetic-'+v);p.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(p)
 f=p/'internal/pixel/sse_plane_arm64.go';s=f.read_text().replace('import "simd/archsimd"','import ("simd/archsimd";"unsafe")')
 s=s.replace('src, ref = src[:len(src):len(src)], ref[:len(ref):len(ref)]','sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))')
 s=s.replace('a, b := src[so:so+w:so+w], ref[ro:ro+w:ro+w]','a,b:=unsafe.Add(sp,so),unsafe.Add(rp,ro)')
 s=s.replace('archsimd.LoadUint8x16(a[x:x+16:x+16]), archsimd.LoadUint8x16(b[x:x+16:x+16])','load16(unsafe.Add(a,x)),load16(unsafe.Add(b,x))')
 if v=='u8square':
  s=s.replace('ssePacket(lo, hi,','probePlanePacket(lo, hi,')
  s+='''\nfunc probePlanePacket(lo,hi archsimd.Int32x4,a,b archsimd.Uint8x16)(archsimd.Int32x4,archsimd.Int32x4){
 d:=a.Max(b).Sub(a.Min(b));l:=d.MulWidenLo(d);dh:=highBytes(d);h:=dh.MulWidenLo(dh)
 ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32());hs:=h.ExtendLo4ToUint32().Add(h.HiToLo().ExtendLo4ToUint32())
 return lo.Add(ls.BitsToInt32()),hi.Add(hs.BitsToInt32())}\n'''
 f.write_text(s)
print('ready')
