//go:build goexperiment.simd && arm64 && !purego

package pixel

import ("simd/archsimd";"unsafe")

// SSE16 computes squared error over sixteen columns, without the signed
// sum needed by variance. Only the requested rows and columns are read;
// accumulation wraps modulo2^32, as in Stats.
func SSE16(src []byte, ss int, ref []byte, rs, h int) uint32 {
	if !Enabled {
		return SSE16Scalar(src, ss, ref, rs, h)
	}
	var lo, hi archsimd.Int32x4

 if uint(h-1)<4096 && (uint(ss)|uint(rs))>>30==0 {
 _=src[(h-1)*ss+15];_=ref[(h-1)*rs+15]
 sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
 var l1,h1 archsimd.Int32x4;y:=0
 for ;y+2<=h;y+=2 {
 lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))
 l1,h1=probeSSEPacket(l1,h1,load16(unsafe.Add(sp,(y+1)*ss)),load16(unsafe.Add(rp,(y+1)*rs)))
 }
 if y<h {lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))}
 lo=lo.Add(l1);hi=hi.Add(h1)
 return uint32(sum32(lo.Add(hi)))
 }
	for y := range h {
		lo, hi = ssePacket(lo, hi, archsimd.LoadUint8x16(src[y*ss:]), archsimd.LoadUint8x16(ref[y*rs:]))
	}
	return uint32(sum32(lo.Add(hi)))
}

func probeSSEPacket(lo,hi archsimd.Int32x4,a,b archsimd.Uint8x16)(archsimd.Int32x4,archsimd.Int32x4){d := a.Max(b).Sub(a.Min(b))
 dl,dh := widen8(d),widen8(highBytes(d))
 return lo.Add(square8(dl)),hi.Add(square8(dh))}
