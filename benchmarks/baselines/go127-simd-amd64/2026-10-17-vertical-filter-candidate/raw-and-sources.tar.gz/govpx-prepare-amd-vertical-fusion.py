from pathlib import Path
root = Path('/private/tmp/govpx-next-amd-vertical-fusion')
p = root / 'scripts/gensimd.go'
s = p.read_text()
start = s.index('func generateMacroInternalLoopFilter()')
prefix, body = s[:start], s[start:]
body = body.replace('for _, orientation := range []string{"Horizontal", "Vertical"} {', 'var amdVertical string\n\tfor _, orientation := range []string{"Horizontal", "Vertical"} {', 1)
marker = 'body = strings.Replace(body, marker, stores.String(), 1)'
assert body.count(marker) == 1
body = body.replace(marker, marker + '\n\t\tif orientation == "Vertical" { amdVertical = body }', 1)
marker = '\tamdData, err := format.Source([]byte(amd))'
assert body.count(marker) == 1
body = body.replace(marker, '\tamd += amdVertical\n' + marker)
p.write_text(prefix + body)
p = root / 'internal/pixel/loopfilter_macro_internal_amd64.go'
s = p.read_text().replace('if !(outer == 1 && step >= 16) || len(p) == 0 {', 'if !((outer == 1 && step >= 16) || (step == 1 && outer >= 20)) || len(p) == 0 {')
s = s.replace('loopFilterMacroInternalFusedHorizontal(p, step, mblimit, blimit, limit, thresh)', 'if outer == 1 {\n loopFilterMacroInternalFusedHorizontal(p, step, mblimit, blimit, limit, thresh)\n } else {\n loopFilterMacroInternalFusedVertical(p, outer, mblimit, blimit, limit, thresh)\n }')
p.write_text(s)
p = root / 'internal/pixel/loopfilter_macro_internal_amd64_test.go'
s = p.read_text().replace('[]bool{false}', '[]bool{false, true}')
p.write_text(s)
# The old decline-only test is replaced by existing full scalar/guard coverage.
p = root / 'internal/pixel/loopfilter_macro_internal_amd64_disabled_test.go'
if p.exists():
    print('Check separate disabled test manually:', p)
print(root)
