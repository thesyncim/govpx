from pathlib import Path
import hashlib,json,tarfile,io,subprocess,re
base=Path('/private/tmp');out=base/'govpx-subpel-pointer-ready';out.mkdir(exist_ok=True);payload={}
for p in base.glob('govpx-next-subpel-pointer*'):
 if p.is_file() and p.suffix in ['.py','.log','.txt','.json','.go']:payload[p.name]=p.read_bytes()
for name in ['govpx-prepare-subpel-pointer.py','govpx-archive-subpel-pointer.py']:payload[name]=(base/name).read_bytes()
names=['internal/pixel/subpel16_amd64.go','internal/pixel/subpel_pointer_amd64_test.go','internal/vp9/dsp/subpel_pointer_native_test.go','scripts/benchmark-amd64.sh']
for name in names:payload['final-production/'+name]=Path(name).read_bytes()
payload['parent/subpel16_amd64.go']=subprocess.check_output(['git','show','c3930581:internal/pixel/subpel16_amd64.go'])
with tarfile.open(out/'raw-and-sources.tar.gz','w:gz') as t:
 for n,d in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size,info.mtime=len(d),0;t.addfile(info,io.BytesIO(d))
(out/'raw-sha256.json').write_text(json.dumps({n:hashlib.sha256(d).hexdigest() for n,d in sorted(payload.items())},indent=2)+'\n')
info={'host':'Apple M4 Max darwin/arm64; Rosetta correctness only','compiler':'Go1.27.2 GOEXPERIMENT=simd GOAMD64=v1 PGOoff','parent':'c3930581b42837b421c9d83389ac435bb05fcb55; AMD production matches mergedmain f56c66d7','assembly':'691cd0512c4829d9ee40d483205dd223f9eb028d','native_speed':'pending native CI; no emulated speed evidence','new_fixture_cases':40,'native_matrix_cases':246,'raw_members':len(payload),'final_source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names},'binaries_sha256':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['govpx-next-subpel-pointer-amd64.test','govpx-next-subpel-pointer-amd64-checkptr.test','govpx-next-subpel-pointer-final-amd64.test','govpx-next-subpel-pointer-dsp-amd64.test','govpx-next-subpel-pointer-assembly-amd64.test']}}
(out/'environment.json').write_text(json.dumps(info,indent=2)+'\n')
for v in ['assembly-rosetta','dsp-rosetta','dsp-cpuoff']:
 text=(base/('govpx-next-subpel-pointer-'+v+'.log')).read_text();cases=re.findall(r'^BenchmarkVP9SubpelPointerNative/\S+\s+\d+\s+[\d.]+ ns/op',text,re.M);assert len(cases)==40 and 'FAIL' not in text,(v,len(cases))
(out/'REPORT.md').write_text('''# AMD subpixel row-load candidate, native performance pending

Parent c3930581; AMD production is identical to mergedmainf56c66d7. This targets
subpelStats16, sampled at0.22sflat/0.24scumulative in PR35's4.52s EPYC7763 VP9
profile. That short profile establishes liveness, not the cause of the measured
VP9 regressions. Existing VP9 kernel controls stayed approximately flat.

Keep all AVX2 sixteen-pixel arithmetic, two bilinear rounding steps, paired
dot-product accumulations and deferred upper-lane fence. Replace repeated row
slices by exact16-byte array loads only after an OR/shift guard proves every
geometry component nonnegative and below2^30. With public w,h positive and
w divisible16, source/ref endpoints and even final unused row increments stay
below2^60. The original two endpoint checks prove all reads, including the
extra bilinear row/column, without padding. Zero/overlap strides and mutually
aliased read-only inputs remain valid. The original checked-slice function is
kept byte-identical after renaming for unusualgeometry, preserving its previous
overflow/panic behavior. No pointer is stored or retained.

Independent review passed bounds, overflow, carries/lifetimes, copied fallback
arithmetic and fixture fairness. Initial wrapper added a hot call; its source
and codegen remain archived. Final selected fast function has no added hot
helper call. Diagnostic cross-codegen drops243 to191 instruction lines and12
to2 bounds-panic sites; only the entry checks remain. Counts are not native
latency or acceptance evidence. All existing qualifying kernels remain intact.

Rosetta correctness only: existing full signed/extreme SubpelSixteenLane tests;
12,288 new legal-phase/alias/zero-overlap-stride/minimal-window cases plus
unusual rs1<<30/MAXINT h1 fallback and short-span panic checks; final root AMD
checkptr2 run passes. Full public DSP all-phase/size tests pass, actual AVX/AVX2
off fallback passes, and all40 new fixtures pass for candidate, CPUoff and
pinned assembly. Emulated ns/op values in1x smoke logs are not speed evidence.

New B.Loop public fixtures:16x8/16x16/32x16/16x32, five phases(fullpel,
horizontal-only,vertical-only,half,both), minimal and unequal padded strides.
Sources start at unaligned3/5, visible spans are exact and backing buffers
include checked read-only canaries. Independent scalar per-pixel equations
retain both rounding stages; final variance and SSE, full input immutability
and observable sinks keep work live. Pinned assembly's phase shortcuts are
legitimate algorithms and remain in the comparison.

Native harness preserves all206 older cases and adds the identical40 fixture
source to ASM/main/current, for246 total, six balanced permutations at150ms.
It records seven benchmark/production hashes and requires selected/extreme
pixel tests, all public subpixel tests and targeted race/checkptr2 before any
timing. Existing35-minute allowance remains. Merge/performance selection waits
for exact-head native results; no current x64 speedup or regression fix claimed.
README files, dependencies, project assembly exclusion and generic fallbacks
remain unchanged. Root PGO/validation logs are preserved with their results.
''')
print(out,len(payload))
