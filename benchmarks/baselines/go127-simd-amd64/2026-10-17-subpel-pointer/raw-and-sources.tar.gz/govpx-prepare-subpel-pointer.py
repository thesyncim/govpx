from pathlib import Path
import subprocess,tarfile,io
repo=Path('/Users/thesyncim/GolandProjects/govpx')
root=Path('/private/tmp/govpx-next-subpel-pointer-candidate');root.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD'],cwd=repo))) as t:
 t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
p=root/'internal/pixel/subpel16_amd64.go';s=p.read_text();old=s[s.index('func subpelStats16('):]
new=old
new=new.replace('\t_ = src[h*ss+w]','\t// With all nonnegative geometry below2^30, both endpoints and row\n\t// increments fit int64. Public dispatch supplies positive h,w and w%16==0.\n\t// The endpoint checks prove every exact16-byte load, including the\n\t// extra bilinear row/column; neither read-only input is written or retained.\n\t_ = src[h*ss+w]',1)
new=new.replace('\tdefer archsimd.ClearAVXUpperBits()', '\tsp, rp := unsafe.Pointer(unsafe.SliceData(src)), unsafe.Pointer(unsafe.SliceData(ref))\n\tdefer archsimd.ClearAVXUpperBits()',1)
for src,off,ptr in [('src','x','sp'),('src','x+1','sp'),('src','so','sp'),('src','so+1','sp'),('ref','ro','rp')]:
 marker=f'archsimd.LoadUint8x16({src}[{off}:])';assert marker in new
 new=new.replace(marker,f'archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add({ptr}, {off})))')
wrapper='''func subpelStats16(src []byte, ss int, ref []byte, rs, w, h int, fx, fy [2]int16) (int, uint32) {
 // Keep the original checked-slice path for unusual geometry. This guard
 // proves pointer-loop integer arithmetic cannot wrap, before any multiply.
 if (uint(w)|uint(h)|uint(ss)|uint(rs))>>30 != 0 {
  return subpelStats16Slices(src,ss,ref,rs,w,h,fx,fy)
 }
 return subpelStats16Pointer(src,ss,ref,rs,w,h,fx,fy)
}
'''
prefix=s[:s.index('func subpelStats16(')].replace('import "simd/archsimd"','import ("simd/archsimd";"unsafe")')
new=new.replace(') (int, uint32) {',') (int, uint32) {\n\t// Prove endpoint arithmetic cannot wrap before selecting pointer loads.\n\tif (uint(w)|uint(h)|uint(ss)|uint(rs))>>30 != 0 {\n\t\treturn subpelStats16Slices(src,ss,ref,rs,w,h,fx,fy)\n\t}',1)
p.write_text(prefix+new+'\n// subpelStats16Slices preserves the original checked-slice behavior for geometry\n// outside the pointer proof. Arithmetic remains identical to the selected path.\n'+old.replace('func subpelStats16(', 'func subpelStats16Slices(',1))
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p)],check=True)
(Path('/private/tmp')/'govpx-next-subpel-pointer-base.txt').write_text(head+'\n')
print(root,head)
